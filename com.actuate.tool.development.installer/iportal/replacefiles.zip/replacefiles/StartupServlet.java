/******************************************************************************
	Actuate Corporation
	Copyright (C) 2003 Actuate Corporation. All rights reserved.
******************************************************************************/
package com.actuate.reportcast.servlets;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBException;

import com.actuate.activeportal.beans.UserInfoBean;
import com.actuate.activeportal.functionality.FeatureManagerImpl;
import com.actuate.activeportal.mds.Manager;
import com.actuate.activeportal.utils.ApplicationConfig;
import com.actuate.activeportal.utils.FileUtility;
import com.actuate.activeportal.utils.IdapiProxyPool;
import com.actuate.birt.BirtViewerUtil;
import com.actuate.common.util.LocaleManager;
import com.actuate.common.util.OsUtil;
import com.actuate.iportal.VolumeProfileManager;
import com.actuate.iportal.common.IPortalConsts;
import com.actuate.iportal.license.LicenseManager;
import com.actuate.iportal.session.iPortalRepository;
import com.actuate.iportal.utils.Utility;
import com.actuate.mashboard.DashboardUtil;
import com.actuate.reportapi.enginemanager.JREMConstants;
import com.actuate.reportapi.enginemanager.JREMException;
import com.actuate.reportapi.enginemanager.ReportEngineConfig;
import com.actuate.reportapi.enginemanager.ReportEngineManager;
import com.actuate.reportcast.common.AcConstants;
import com.actuate.reportcast.resources.ResourceCache;
import com.actuate.reportcast.resources.ResourceManager;
import com.actuate.reportcast.utils.AcTimeZone;
import com.actuate.reportcast.utils.Cleanup;
import com.actuate.reportcast.utils.CookieHandlerBean;
import com.actuate.reportcast.utils.DefaultParamHandler;
import com.actuate.reportcast.utils.HttpResponse;
import com.actuate.reportcast.utils.StaticFuncs;
import com.actuate.reportcast.utils.TimeZoneManager;
import com.actuate.reportcast.utils.UserMap;
import com.actuate.reportcast.utils.logging.DailyRollingFileWriter;
import com.actuate.reportcast.utils.logging.LogCategory;
import com.actuate.reportcast.utils.logging.PropertyFormatter;
import com.actuate.reportservice.VolumeManager;
import com.actuate.transientstore.TransientConfigurationException;
import com.actuate.transientstore.TransientManager;
import com.actuate.web.StartupUtil;
import com.actuate.web.extension.IWebXML;
import com.actuate.web.extension.WebExtensionManager;
import com.actuate.web.extension.helper.webxml.HelpDocBaseUtil;
/**
 * This servlet is used to initilaize the web application on startup and for viewing its
 * status during operation. 
 * 
 * This servlet initializes:
 * - LocaleManager by reading locale data from localemap.xml file 
 * - TimeZoneManager by reading time zones data from timezonemap.xml
 * - Logging mechanism by creating the log files and initializing the logging objects. 
 * - Initializes the folder used for downloading composite documents.
 */
public class StartupServlet extends AcServlet {

	final public static String LOCALES_KEY = "com.actuate.locales";
	final public static String TIMEZONES_KEY = "com.actuate.timezones";
    public static final Logger logger = Logger.getLogger(StartupServlet.class.getName());
    private String licenseFileDir = "/WEB-INF/";
    private String ajcLicenseFilePath = licenseFileDir+"ajclicense.xml";
    private String brdLicenseFilePath = licenseFileDir+"brdlicense.xml";
    private static int gracePeriodForThreadpoolTimeouts = 30 ; // seconds
    private boolean bStartJREM = true;
    private static String homePage = "www.actuate.com/iportal9";
    
 
	/**
	 *
	 */
	public StartupServlet() {

	}

	public synchronized void stopJREM( )
	{
		if ( !jremStarted )
    	{
    		return;
    	}

        try
        {
            ReportEngineManager.getInstance().shutdown( true, 0 );
            jremStarted = false;
        }
        catch ( JREMException e )
        {
            logger.severe( "JREM shutdown"
                    + System.getProperty( "line.separator" )
                    + e.getLocalizedMessage() );
        }
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#destroy()
	 */
	public void destroy()
    {
		stopJREM( );
		
        TransientManager.getInstance().destroyAndCleanup();
        super.destroy();
        FileUtility.destroy();
        logger.warning( "iportal shutdown done!" );
    }

	/**
	 * Initialize the web xml init parameters using end user's extension points 
	 * @param sc
	 */
	public void initWebXMLExtension( ServletConfig sc )
	{
        WebExtensionManager em = WebExtensionManager.initialize( sc );
        
        IWebXML  ext = em.getWebXMLExtension();
        Map<String, String> defaultValues = ext.getStartupInitParameters( sc.getServletContext() );
        StartupUtil.init(defaultValues);
	}
	
	/**
	 *
	 * @param      sc
	 * @exception  ServletException
	 */
	public void init(ServletConfig sc) throws ServletException {
        super.init(sc);
		ApplicationConfig.setServletConfig(sc);

		try {
	        ServletContext servletContext = sc.getServletContext();
	        initWebXMLExtension( sc );
	        
            String sTempFolder = StartupUtil.getDefaultInitParameter( "TEMP_FOLDER_LOCATION" );
	        String defaultTempPath = AcConstants.$$TEMP_FOLDER$$;
	        String fileSeparator = System.getProperty("file.separator");

	        String subFolderNameForTemp = AcConstants.SERVLET_CONTAINER.toLowerCase()
                    + fileSeparator
                    + AcConstants.IPORTAL.toLowerCase()
                    + fileSeparator + "temp";
	        sTempFolder = StaticFuncs.getFolderPath( sTempFolder,
                    defaultTempPath, subFolderNameForTemp );
            sTempFolder = sTempFolder == null ? "" : sTempFolder.trim();
            sTempFolder = sTempFolder.toLowerCase().startsWith(
                    AcConstants.$$TEMP_FOLDER$$.toLowerCase() ) ? null
                    : sTempFolder;

	        sTempFolder = initTempFolder(sc, sTempFolder);

            Cleanup cleanupTempFolder = new Cleanup();
            // delete contents of temp folder may take time (IO operations)
            // In order to prevent delaying of jar file loading, 
            // move files to a different folder and delete them at the end of iportal startup.
            cleanupTempFolder.init( sTempFolder );
            
			FileUtility.setServletConfig(sc);
			
			String definedLogFilePath = StartupUtil.getDefaultInitParameter( "LOG_FILE_LOCATION" );
	        String logFilePath = definedLogFilePath;
            String defaultLogPath = AcConstants.$$LOGFILE_LOCATION$$;
            String subFolderName = AcConstants.SERVLET_CONTAINER.toLowerCase() + fileSeparator + AcConstants.IPORTAL.toLowerCase();
            logFilePath = StaticFuncs.getFolderPath( logFilePath, defaultLogPath,
                    subFolderName );
            
            // the return path can be null/empty string even definedLogFilePath is valid.
            
           	if ( ( logFilePath == null || logFilePath.length( ) == 0 )
           			&& ( definedLogFilePath != null && definedLogFilePath.length( ) > 0 ))
           		logFilePath = definedLogFilePath;
            
            logFilePath = logFilePath == null? "":logFilePath.trim();
            
            logFilePath = logFilePath.toLowerCase().startsWith( AcConstants.$$LOGFILE_LOCATION$$.toLowerCase() )? null:logFilePath;

            initLogFiles( sc, logFilePath );

			initLocaleManager(sc);
			initTimeZoneManager(sc);
            initJULLogging(sc, logFilePath);

			initSettings(sc);
			initDownloadDir(sc);
			initUserCache(sc);
			initMDSManager();
			initWorkgroupHostname();
			initJSAPI(sc);
            String threshold = StartupUtil.getDefaultInitParameter( "SAVE_DASHBOARD_THRESHOLD" );
            if (threshold != null && threshold.length() > 0)
            {
                try
                {
                    StaticFuncs.setSaveMashBoardThreshold( Integer.parseInt( threshold ) );
                }
                catch (Exception e)
                {
                    StaticFuncs.setSaveMashBoardThreshold( 1 );
                }
            }
			StaticFuncs.setWebAppPath(servletContext.getRealPath("/"));
			com.actuate.activeportal.skin.SkinManagerEx.init(servletContext);
			com.actuate.activeportal.functionality.FeatureManagerImpl.init();
			com
				.actuate
				.activeportal
				.functionality
				.AnalyticsExpLevelManager
				.init(
				sc);

			servletContext.setAttribute(
				LOCALES_KEY,
				LocaleManager.instance().getAvailableLocales());
			servletContext.setAttribute(
				TIMEZONES_KEY,
				TimeZoneManager.instance().getDisplayedTimeZones());

			logSystemInformation();
			initDocBase(sc);
			
			/* SCR 81210: We don't need to suppress, Tomcat does it for us, now.
			// SCR 74421: We want to suppress standard output
			DummyOutputStream output = new DummyOutputStream();
			java.io.PrintStream redirectOutput = new java.io.PrintStream(output);
			System.setOut(redirectOutput);
			System.setErr(redirectOutput);		*/
            
            // JREM needs workspace so initialize workspace now
            initializeWorkSpace( servletContext );
            // initialize JREM after we initialize JUL log
            bStartJREM = StartupUtil.doesJREMNeedToStart( );
            
            InputStream inpStr = null;
            //read servlet context property for BRDPro invocation 
            String isBRD = (String) servletContext.getAttribute("ACTUATE_DESIGNER_PRO" );
            
            if(isBRD != null && isBRD.equals("true"))
            {
            	inpStr = FileUtility.getResourceAsStream(brdLicenseFilePath);
            	LicenseManager.initialize(inpStr, brdLicenseFilePath, true);
            }
            else
            {
            	inpStr = FileUtility.getResourceAsStream(ajcLicenseFilePath);
            	LicenseManager.initialize(inpStr, ajcLicenseFilePath, false);
            	 
            	//if not AJC then it is Information Console
            	if (inpStr == null)
            	{
            		LicenseManager.initialize();
            	}
            }
            
            // Start JREM if needed and disable performance options if not licensed
            if ( bStartJREM )
            {
            	startJREM(servletContext);
            }
            
            Thread cleanupTempFolderThread = new Thread(cleanupTempFolder);
            cleanupTempFolderThread.start();  
            
    		StaticFuncs.dbgln("InformationConsole started......");
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			StaticFuncs.dbgln(e.getMessage());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			StaticFuncs.dbgln(e.getMessage());
		}

	}

    private void initJULLogging(ServletConfig sc, String logFilePath) {
		
        //initialize JUL log       
        AcTimeZone defaultTz = TimeZoneManager.instance().getDefaultTimeZone();
        // create a GregorianCalendar with default time zone and the current
        // date and time
        Calendar calendar = new GregorianCalendar( defaultTz );
        Date currentDate = new Date();
        calendar.setTime( currentDate );
        TimeZone tz = calendar.getTimeZone();
        String tzId = tz.getID();
        if ( tz.inDaylightTime( currentDate ) == true )
        {
            String target = "Standard";
            String replacement = "Daylight";
            tzId = tzId.replaceAll( target, replacement );
        }		
		
        final SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyyMMMdd_HH_mm_ss_" );
        dateFormat.setCalendar( calendar );
        String timeStamp = dateFormat.format( currentDate ) + tzId.replaceAll( "/", "_" );
        String displayTime = timeStamp.replaceAll( " ", "_" );
        // retrieve config from web.xml
        ServletContext servletContext = sc.getServletContext();
        String consoleLogLevel = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JUL_LOG_CONSOLE_LEVEL );
        String logLevel = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JUL_LOG_FILE_LEVEL );
        int logFileSize = Integer.parseInt( StartupUtil.getDefaultInitParameter(
        		IPortalConsts.WEBXML_JUL_LOG_FILE_SIZE_KB ) );
        int logFileCount = Integer.parseInt( StartupUtil.getDefaultInitParameter(
        		IPortalConsts.WEBXML_JUL_LOG_FILE_COUNT ) );
        String loggingFlag = StartupUtil.getDefaultInitParameter(IPortalConsts.WEBXML_ENABLE_JUL_LOG );
        String logPath = logFilePath == null? "": logFilePath;
        
        File logFolder = new File(logPath);
        
        if (!logFolder.exists()) {

			// If the log directory specified in the web.xml is invalid
			// we try to find the log directory under this application root

			ServletContext context = sc.getServletContext();

			String sRootDir = context.getRealPath("");
			if (sRootDir == null) {
				try {
					URL urlRootDir = context.getResource("/");
					if (urlRootDir != null) {
						sRootDir = urlRootDir.getPath();
					}
				} catch (java.net.MalformedURLException ex) {
					ex.printStackTrace();
				}
			}

			if (sRootDir == null) {
				// This condition should never occur.
				// However, it has been kept just in case some servlet container
				// does not implement the api correctly.
				sRootDir = System.getProperty("user.dir");
			}

			// Create a logs directory under this directory.
			String sSeparator = System.getProperty("file.separator");
			sRootDir += (sRootDir.endsWith(sSeparator) ? "" : sSeparator)
					+ "logs";
			logFolder = new File(sRootDir);

			if (logFolder.exists()) // Check whether the directory exists
			{
				// If the file exists. Check that it is a directory
				if (!logFolder.isDirectory()) {
					// If it isn't then set the location to the current user
					// directory.
					sRootDir = System.getProperty("user.dir");
				}
			} else {
				// If not try creating the directory.
				if (!logFolder.mkdirs()) {
					// If we are unsuccessful in creating the directory. Set the
					// path to the current user directory.
					sRootDir = System.getProperty("user.dir");
				}
			}
			
			logPath = sRootDir;

		}
        
        logPath += "/reportService";
        
        if ( loggingFlag.compareToIgnoreCase( "TRUE" ) == 0 )
        {

            JULLog logMgr = new JULLog( 0, displayTime );
            
            try
            {
            	logMgr.startLogging( logPath, logLevel, logFileSize, logFileCount, true, consoleLogLevel );
            }
            catch(Exception e)
            {
            	// We ignore any error when initializing JUL logging
            	e.printStackTrace();                
            }
        }		
	}

	/**
	 * 
	 */
	private void logSystemInformation() {
		// RunTime
		StaticFuncs.dbgln("FREE MEMORY\t" + Runtime.getRuntime().freeMemory());
		StaticFuncs.dbgln(
			"TOTAL MEMORY\t" + Runtime.getRuntime().totalMemory());

		// System
		Enumeration enumeration = System.getProperties().keys();
		while (enumeration.hasMoreElements()) {
			String key = (String) enumeration.nextElement();
			String value = System.getProperty(key);
			StaticFuncs.dbgln(key + "\t" + value);
		}
	}

	/**
	 *
	 * @param      req
	 * @param      res
	 * @param      userMap
	 * @param      dph
	 * @exception  ServletException
	 * @exception  IOException
	 */
	protected void handleServletRequest(
		HttpServletRequest req,
		HttpServletResponse res,
		UserMap userMap,
		DefaultParamHandler dph)
		throws ServletException, IOException {
		//StaticFuncs.dbgln("StartupServlet: Real Path = " + ((getServletConfig()).getServletContext()).getRealPath(""));

		final LocaleManager lm = LocaleManager.instance();
		final ResourceManager rm =
			StaticFuncs.getResources(getClass(), lm.getDefaultLocale());

		final OutputStream os = res.getOutputStream();
		String stemp =
			"<html><head><title>"
				+ rm.getString(R_servlets.TTL_SERVER_STATUS)
				+ "</title><head>\n";
		//i18n
		os.write(stemp.getBytes());
		os.write(
			"<META HTTP-EQUIV=\"refresh\" content=\"10;URL=\"/servlets/ServerStatus\">"
				.getBytes());
		os.write("<body>\n".getBytes());

		// RESOURCE CACHE
		final ResourceCache rc = ResourceCache.instance();
		rc.analyseCacheContents(os, lm.getDefaultLocale());

		// USER MAP
		Utility.analyseUserMap(os);
        //MDS info
        Manager.getInstance().writeMDSDetailsToHTML(os);
        

		os.write("\n</body></html>".getBytes());
	}

	private int getIntegerValue(String size)
	{
		int max_size = -1;
		try {
			max_size = Integer.parseInt(size);
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}
		
		// Value has to be greater than 0.  if it is not, then set to -1 so that we can fetch everything.
		if ( max_size <= 0 )
		{
			max_size = -1;
		}
		return max_size;
	}
	
	private void initJSAPI(ServletConfig scg)
	{
		final ServletContext sc = scg.getServletContext();
		String sFetchSize = StartupUtil.getDefaultInitParameter("AUTOSUGGEST_FETCH_SIZE");
		String sListSize = StartupUtil.getDefaultInitParameter("AUTOSUGGEST_LIST_SIZE");
		String sAutosuggestDelay =StartupUtil.getDefaultInitParameter("AUTOSUGGEST_DELAY");
		int minDelay = getIntegerValue(sAutosuggestDelay);
		if ( minDelay <= 0 )
		{
			minDelay = 500;
		}
		
		Utility.setJSAPIFetchSize(getIntegerValue(sFetchSize));
		Utility.setJSAPIListSize(getIntegerValue(sListSize));
		Utility.setJSAPIAutoSuggestDelay(minDelay);
		
		Utility.setDefaultAutoSaveDashboardDelay(StartupUtil.getDefaultInitParameter("AUTO_SAVE_DASHBOARD_DELAY"));
	}
	
	private void initWorkgroupHostname()
	{
		String hostname = "Workgroup";
        try
        {
        	 hostname = InetAddress.getLocalHost().getHostName();
        }
        catch(Exception ex)
        {
        	StaticFuncs.dbgln(ex.getMessage());
        }
        Utility.setWorkgroupHostname(hostname);
	}

	private void initUserCache(ServletConfig scg) {
		final ServletContext sc = scg.getServletContext();
		String sLoginTimeOut = StartupUtil.getDefaultInitParameter("LOGIN_TIMEOUT");

		if (sLoginTimeOut != null) {
			try {
				Utility.setLoginTimeout(Long.parseLong(sLoginTimeOut));
			} catch (NumberFormatException nfe) {
				nfe.printStackTrace();
				Utility.setLoginTimeout(60 * 60 * 1000);
			}
		}

		StaticFuncs.dbgln("LOGIN_TIMEOUT\t" + sLoginTimeOut);

	}

	/**
	 *
	 * @param      scg
	 */
	private void initLocaleManager(ServletConfig scg) {
		final ServletContext sc = scg.getServletContext();
		String sCP = sc.getRealPath("");
		URL urlCP = null;
		String sDefaultLocale = StartupUtil.getDefaultInitParameter("DEFAULT_LOCALE");
		if (sDefaultLocale == null
			|| "$$Default_Locale$$".equalsIgnoreCase(sDefaultLocale)) {
			sDefaultLocale = "en_US";
		}
		sDefaultLocale = sDefaultLocale.trim().toLowerCase();
		if (sCP == null) {
			try {
				urlCP = sc.getResource("/WEB-INF/localemap.xml");
			} catch (java.net.MalformedURLException ex) {
				ex.printStackTrace();
			}
            LocaleManager.initialize(urlCP, sDefaultLocale);
		} else {
            String sFS = System.getProperty("file.separator");
            String sXMLFileName = sCP + sFS + "WEB-INF" + sFS + "localemap.xml";
            LocaleManager.initialize(sXMLFileName, sDefaultLocale);
            
		}

		StaticFuncs.dbgln("DEFAULT_LOCALE\t" + sDefaultLocale);
	}

	/**
	 *
	 * @param      scg
	 */
	private void initTimeZoneManager(ServletConfig scg) {
		ServletContext sc = scg.getServletContext();
		String sCP = sc.getRealPath("");
		URL urlCP = null;
		String sDefaultTimeZone = StartupUtil.getDefaultInitParameter("DEFAULT_TIMEZONE");
		if (sDefaultTimeZone == null
			|| "$$Default_Timezone$$".equals(sDefaultTimeZone)) {
			// sDefaultTimeZone = "America/Los_Angeles";
			sDefaultTimeZone = TimeZone.getDefault().getID();
		}
		sDefaultTimeZone = sDefaultTimeZone.trim().toLowerCase();
		StaticFuncs.dbgln("DEFAULT_TIMEZONE\t" + sDefaultTimeZone);
		if (sCP == null) {
			try {
				urlCP = sc.getResource("/WEB-INF/TimeZones.xml");
			} catch (java.net.MalformedURLException ex) {
				ex.printStackTrace();
			}
			TimeZoneManager.initialize(urlCP, sDefaultTimeZone);
		} else {
			TimeZoneManager.initialize(sCP, sDefaultTimeZone);
		}
		TimeZoneManager.instance().initDefaultTimeZone();
		sDefaultTimeZone =
			TimeZoneManager.instance().getDefaultTimeZone().getName();
		StaticFuncs.dbgln("DEFAULT_TIMEZONE\t" + sDefaultTimeZone);

	}

	/**
	 *
	 * @param      scg
	 */
	private void initLogFiles(ServletConfig scg, String fileLocation) {
		ServletContext sc = scg.getServletContext();
		String sEnableLog =
			((StartupUtil.getDefaultInitParameter("ENABLE_ERROR_LOGGING")).trim())
				.toLowerCase();
		
		String sLogFileLocation = fileLocation == null? null:fileLocation.trim();
		sLogFileLocation = "".equalsIgnoreCase( sLogFileLocation )? null: sLogFileLocation;
		sc.log("Initialising logging mechanism");

		File f = null;
		if (sLogFileLocation != null)
		{
            f = new File( sLogFileLocation );
            if ( !f.exists() )
            {
                boolean bMkdir = f.mkdirs();
                if ( !bMkdir )
                {
                    logger.warning( "StartupServlet: cannot create log folder: "
                            + sLogFileLocation );
                    sLogFileLocation = null;
                }
            }
            else if ( !f.isDirectory() )
            {
                logger.warning( "StartupServlet: log path is not a directory: " + sLogFileLocation );
                sLogFileLocation = null;
            }
        }

		if (sLogFileLocation == null) {
			//If the location is not specified write the logs into a logs directory in the web application root directory.
			String sRootDir = sc.getRealPath("");
			if (sRootDir == null) {
				try {
					URL urlRootDir = sc.getResource("/");
					if (urlRootDir != null) {
						sRootDir = urlRootDir.getPath();
					}
				} catch (java.net.MalformedURLException ex) {
					ex.printStackTrace();
				}
			}
			if (sRootDir == null) {
				//This condition should never occur.
				//However, it has been kept just in case some servlet container does not implement the api correctly.
				sRootDir = System.getProperty("user.dir");
			}
			//Create a logs directory under this directory.
			String sSeparator = System.getProperty("file.separator");
			sRootDir += (sRootDir.endsWith(sSeparator) ? "" : sSeparator)
				+ "logs";
			f = new File(sRootDir);
			if (f.exists()) //Check whether the directory exists
				{
				//If the file exists. Check that it is a directory
				if (!f.isDirectory()) {
					//If it isn't then set the location to the current user directory.
					sRootDir = System.getProperty("user.dir");
				}
			} else {
				//If not try creating the directory.
				if (!f.mkdirs()) {
					//If we are unsuccessful in creating the directory. Set the path to the current user directory.
					sRootDir = System.getProperty("user.dir");
				}
			}
			sLogFileLocation = sRootDir;
		}
		sc.log("Writing logs to " + sLogFileLocation);

		int iMaxBackup = 30;
		if (sEnableLog.equals("true")) {
			sc.log("Enabling logging mechanism");
			LogCategory cat = LogCategory.getInstance("errorLog");

			// Bhavin : a New category for logging SOAP faults
			LogCategory lcSOAPFault = LogCategory.getInstance("soapFaultLog");

			PropertyFormatter formatter = new PropertyFormatter();
//			formatter.setFormat(
//				"%d|%P{class}|%L|%P{errorCode}|%m|%E{\r\n=<BR>,\t=\\t}%n");
			formatter.setFormat( "%d%n%P{class}%n%L%P{errorCode}%n%m%n%E%n" );

			PropertyFormatter pfSOAP = new PropertyFormatter();
			pfSOAP.setFormat("%n%n%P{class}%n%m%n");

			String sRollOver =
				((StartupUtil.getDefaultInitParameter("ERROR_LOG_FILE_ROLLOVER")).trim())
					.toLowerCase();
			try {
				DailyRollingFileWriter daily =
					new DailyRollingFileWriter(
						sLogFileLocation + "/admin.log",
						true);

				// Bhavin : logging SOAP faults
				DailyRollingFileWriter SOAPdaily =
					new DailyRollingFileWriter(
						sLogFileLocation + "/SOAPFault.log",
						false);
				SOAPdaily.setFormatter(pfSOAP);
				daily.setFormatter(formatter);

				if (sRollOver.equals("yearly")) {
					daily.setRollOver(DailyRollingFileWriter.YEARLY);
					SOAPdaily.setRollOver(DailyRollingFileWriter.YEARLY);
				} else if (sRollOver.equals("daily")) {
					daily.setRollOver(DailyRollingFileWriter.DAILY);
					SOAPdaily.setRollOver(DailyRollingFileWriter.DAILY);
				} else if (sRollOver.equals("weekly")) {
					daily.setRollOver(DailyRollingFileWriter.WEEKLY);
					SOAPdaily.setRollOver(DailyRollingFileWriter.WEEKLY);
				} else {
					daily.setRollOver(DailyRollingFileWriter.MONTHLY);
					SOAPdaily.setRollOver(DailyRollingFileWriter.MONTHLY);
				}

				try {
					iMaxBackup =
						Integer.parseInt(
							(StartupUtil.getDefaultInitParameter("MAX_BACKUP_ERROR_LOGS"))
								.trim());
				} catch (Exception ex) {
					sc.log(
						"Actuate: Invalid number of days specified:  "
							+ StartupUtil.getDefaultInitParameter("MAX_BACKUP_ERROR_LOGS"));
					iMaxBackup = 30;
				}

				daily.setMaxPeriod(iMaxBackup);
				SOAPdaily.setMaxPeriod(iMaxBackup);

				cat.addWriter(daily);
				cat.setLevel(LogCategory.WARNING);

				// Bhavin : Setting up SOAP fault log category
				lcSOAPFault.addWriter(SOAPdaily);
				lcSOAPFault.setLevel(LogCategory.ERROR);
			} catch (FileNotFoundException ex) {
				cat.setLevel(LogCategory.DONT_LOG);
				lcSOAPFault.setLevel(LogCategory.DONT_LOG);
				sc.log("Actuate: File Not Found:  " + ex.toString(), ex);
			}
		}

		StaticFuncs.dbgln("ENABLE_ERROR_LOGGING\t" + sEnableLog);

		sEnableLog =
			((StartupUtil.getDefaultInitParameter("ENABLE_DEBUG_LOGGING")).trim())
				.toLowerCase();
		if (sEnableLog.equals("true") || sEnableLog.equals("info") ) {
            int category = LogCategory.DEBUG;
            if(sEnableLog.equals("info"))
                category = LogCategory.INFO;
			LogCategory cat = LogCategory.getInstance("debugLog");
			PropertyFormatter formatter = new PropertyFormatter();
			formatter.setFormat("%m");
			//ConsoleWriter writer = new ConsoleWriter();
			try {
				DailyRollingFileWriter writer =
					new DailyRollingFileWriter(
						sLogFileLocation + "/debug.log",
						true);
				writer.setFormatter(formatter);
				writer.setRollOver(DailyRollingFileWriter.DAILY);
				writer.setMaxPeriod(iMaxBackup);
				cat.addWriter(writer);
                cat.setLevel(category);
			} catch (FileNotFoundException ex) {
				cat.setLevel(LogCategory.DONT_LOG);
				sc.log("Actuate: File Not Found:  " + ex.toString(), ex);
			}
		}
		StaticFuncs.dbgln("ENABLE_DEBUG_LOGGING\t" + sEnableLog);

		// Enable dedicated stress test log.
		sEnableLog = ( ( StartupUtil.getDefaultInitParameter( "ENABLE_STRESS_LOGGING" ) )
				.trim( ) ).toLowerCase( );
		if ( sEnableLog.equals( "true" )  )
		{
            int category = LogCategory.INFO;
			LogCategory cat = LogCategory.getInstance( "stressLog" );
			PropertyFormatter formatter = new PropertyFormatter( );
			formatter.setFormat( "%m" );
			try
			{
				DailyRollingFileWriter writer = new DailyRollingFileWriter(
						sLogFileLocation + "/stress.log", true );
				writer.setFormatter( formatter );
				writer.setRollOver( DailyRollingFileWriter.DAILY );
				writer.setMaxPeriod( iMaxBackup );
				cat.addWriter( writer );
                cat.setLevel (category );
			}
			catch ( FileNotFoundException ex )
			{
				cat.setLevel( LogCategory.DONT_LOG );
				sc.log( "Actuate: File Not Found:  " + ex.toString( ), ex );
			}
		}

		StaticFuncs.dbgln("ENABLE_STRESS_LOGGING\t" + sEnableLog);
		StaticFuncs.dbgln("LOG_FILE_LOCATION\t" + sLogFileLocation);

		FileUtility.setLogDirectory(new File(sLogFileLocation));

	}

	/**
	 * @param      scg
	 */
	private final void initMDSManager() {
		Boolean mdsEnabled = ApplicationConfig.getMdsEnabled();
        //msRefresh is 0 if MDS_ENABLED does not exist in web.xml or is false
        long msRefresh = 0;
		if (mdsEnabled != null && mdsEnabled.booleanValue()) 
		{
	        Long mdsFrequency = ApplicationConfig.getMdsRefreshFrequency();
		    msRefresh = mdsFrequency == null ? 0 : 1000 * mdsFrequency.longValue();
		}
		com.actuate.activeportal.mds.Manager.setMsUpdateInterval(msRefresh);
		com.actuate.activeportal.mds.Manager.setDisabled(msRefresh <= 0);

		StaticFuncs.dbgln(
			"MDS_ENABLED\t"
				+ !com.actuate.activeportal.mds.Manager.isDisabled());
		StaticFuncs.dbgln(
			"MDS_LIST_REFRESH_FREQUENCY\t"
				+ com.actuate.activeportal.mds.Manager.getMsUpdateInterval()
					/ 1000);
	}

	class GarbageCollectorThread implements Runnable {
		public void run() {
			while (true) {
				try {
					Thread.sleep(StaticFuncs.getGcIntervalMillis());
					StaticFuncs.triggerGC();
				} catch (InterruptedException e) {
				}
			}
		}
	}

	/**
	 * Initialize:<BR>
	 * <LI>Cookie's domain and path
	 * <LI>Forced garbage collection
	 * <LI>Execute report wait time 
	 * <LI>JVM's locale: Locale.setDefault
	 * 
	 * @param      scg
	 */
	private final void initSettings(ServletConfig scg) {
		ServletContext sc = scg.getServletContext();

		// INITIALIZE COOKIE HANDLER BEAN
		String cookieEnabled = StartupUtil.getDefaultInitParameter("COOKIE_ENABLED");
		String cookiePath = StartupUtil.getDefaultInitParameter("COOKIE_PATH");
		String cookieDomain = StartupUtil.getDefaultInitParameter("COOKIE_DOMAIN");
		String cookieSecure = StartupUtil.getDefaultInitParameter("COOKIE_SECURE");
		if (null == cookiePath)
			cookiePath = "/";
		CookieHandlerBean.setCookiePath(cookiePath);
		if (null != cookieDomain && cookieDomain.length() > 0)
			CookieHandlerBean.setCookieDomain(cookieDomain);
		CookieHandlerBean.setCookieWritingEnabled(
			Boolean.valueOf(cookieEnabled).booleanValue());

		if ( "true".equalsIgnoreCase(cookieSecure))
		{
			CookieHandlerBean.setCookieSecure(true);
		}
		
		String sServerQueryTimeout =
			StartupUtil.getDefaultInitParameter("SERVER_QUERY_TIMEOUT");
		String sForcedGCInterval = StartupUtil.getDefaultInitParameter("FORCED_GC_INTERVAL");
		String sWaitTime = StartupUtil.getDefaultInitParameter("EXECUTE_REPORT_WAIT_TIME");
		String jvmLanguage = StartupUtil.getDefaultInitParameter("JVM_LANGUAGE");
		String jvmCountry = StartupUtil.getDefaultInitParameter("JVM_COUNTRY");
		String sPoolSize = StartupUtil.getDefaultInitParameter("MAX_CONNECTIONS_PER_SERVER");
		String sConnTimeOut = StartupUtil.getDefaultInitParameter("CONNECTION_TIMEOUT");
		String cacheControl = StartupUtil.getDefaultInitParameter("CACHE_CONTROL");
		String sMaxListSize = StartupUtil.getDefaultInitParameter("MAX_LIST_SIZE");
		String sMemListSize = StartupUtil.getDefaultInitParameter("MEMBERSHIP_LIST_SIZE");
		String sEnableSaveView =
			StartupUtil.getDefaultInitParameter("ANALYTICS_ENABLE_SAVE_VIEW");
		String sEnableAppletCache =
			StartupUtil.getDefaultInitParameter("ANALYTICS_ENABLE_ONETIME_DOWNLOAD");
		String sAnalyticsWatermark = StartupUtil.getDefaultInitParameter("ANALYTICS_WATERMARK");
		String sAnalyticsAllowViewSourceRecords =
			StartupUtil.getDefaultInitParameter("ANALYTICS_CUBE_VIEW_RECORDS");
		String sAnalyticsCubeHeight =
			StartupUtil.getDefaultInitParameter("ANALYTICS_CUBE_VIEWER_HEIGHT");
		String sAnalyticsCubeWidth =
			StartupUtil.getDefaultInitParameter("ANALYTICS_CUBE_VIEWER_WIDTH");
		String sAnalyticsBaseExpLevelName =
			StartupUtil.getDefaultInitParameter("ANALYTICS_BASE_EXPLEVEL_NAME");

		String sUserJSAPIParameterPage =
			StartupUtil.getDefaultInitParameter("USE_JSAPI_PARAMETER_PAGE");
		if( sUserJSAPIParameterPage == null )
			sUserJSAPIParameterPage	= "true";

		String sEnableFacebook = StartupUtil.getDefaultInitParameter("ENABLE_FACEBOOK");
		if( sEnableFacebook == null )
			sEnableFacebook = "false";
		
		String sFacebookBaseURL = StartupUtil.getDefaultInitParameter("FACEBOOK_BASE_URL");
		
		String sDashboardSharedResources = StartupUtil.getDefaultInitParameter("DASHBOARD_SHARED_RESOURCES");
		
		String defaultDashboard = StartupUtil.getDefaultInitParameter("DEPLOYED_WITH_ACTUATE_DASHBOARD");
		Utility.setUseDefaultDashboard(Boolean.valueOf(defaultDashboard).booleanValue());

		String enableBRSLink = StartupUtil.getDefaultInitParameter("ENABLE_BRS_LINK");
		Utility.setBRSLink(Boolean.valueOf(enableBRSLink).booleanValue());

		String sessionLevelID = StartupUtil.getDefaultInitParameter("SESSION_DEFAULT_PARAMETER_VALUE_ID");
		com.actuate.parameter.ReportParameterUtil.setSessionLevelParameterID(sessionLevelID);
		
		// INITIALIZE SETTINGS

		int serverQueryTimeout = 8000;
		try {
			serverQueryTimeout = Integer.parseInt(sServerQueryTimeout) * 1000;
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}

		// GC settings
		long gcIntervalMillis = 0;
		try {
			gcIntervalMillis = Long.parseLong(sForcedGCInterval) * 1000;
			StaticFuncs.setGcIntervalMillis(gcIntervalMillis);
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}
		boolean forceGC = gcIntervalMillis > 0;

		int waitTime = StaticFuncs.getExecuteReportWaitTime();
		try {
			waitTime = Integer.parseInt(sWaitTime);
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}

		// PROXY POOL
		int proxyPoolSize = IdapiProxyPool.getPoolSize();
		try {
			proxyPoolSize = sPoolSize == null ? 100 : Integer.parseInt(sPoolSize);

			if (proxyPoolSize <= 0)
				proxyPoolSize = 100;

			IdapiProxyPool.setPoolSize(proxyPoolSize);

		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}

		// CONNECTION_TIMEOUT
		int connTimeOut = 0;
        try
        {
            connTimeOut = sConnTimeOut == null? 0 : Integer.parseInt( sConnTimeOut );
        }
        catch ( Exception e )
        {
            logger.warning( "can not convert sConnTimeOut=" + sConnTimeOut + ". set connTimeout to 0");
            // set connTimeOut to 0 if exception happens.
            connTimeOut = 0;
        }
        StaticFuncs.setConnTimeOut( connTimeOut );
        
        String sIdapiTimeout = StartupUtil.getDefaultInitParameter("IDAPI_TIMEOUT");
        int idapiTimeout = StaticFuncs.getIdapiTimeout( sIdapiTimeout );
        IdapiProxyPool.setTimeOut( idapiTimeout );

		try {
			Class clazz =
				Class.forName("com.actuate.activeportal.utils.Config");
			Method m = clazz.getDeclaredMethod("getHelpContext", new Class[] {
			});
			String s = (String) m.invoke((Object[])null, (Object[])null);
			sc.setAttribute("com.actuate.help.context", s);
			StaticFuncs.setApplicationType(
				StaticFuncs.ACTIVE_PORTAL_APPLICATION);
		} catch (ClassNotFoundException ex) {
			sc.setAttribute("com.actuate.help.context", "iServer");
			StaticFuncs.setApplicationType(
				StaticFuncs.MGMT_CONSOLE_APPLICATION);
		} catch (Exception ex) {
			sc.setAttribute("com.actuate.help.context", "UserConsole");
			StaticFuncs.setApplicationType(
				StaticFuncs.ACTIVE_PORTAL_APPLICATION);
		}

		// JVM's Locale
		boolean changeLocale = false;
		Locale defaultLocale = Locale.getDefault();
		Locale jvmLocale = Locale.US;
		if (defaultLocale != Locale.US) {
			changeLocale = "ar".equals(defaultLocale.getLanguage());
		}
		if (changeLocale) {
			if (null != jvmLanguage && null != jvmCountry)
				jvmLocale = new Locale(jvmLanguage, jvmCountry);
			Locale.setDefault(jvmLocale);
		}

		// start the GC thread		
		if (forceGC) {
			Thread gcThread = new Thread(new GarbageCollectorThread());
			gcThread.start();
		}

		// init the cache-control and cache-expiration variables.
		if (cacheControl != null && cacheControl.length() > 0)
			StaticFuncs.setCacheControl(cacheControl);

		//StaticFuncs.		
		//		StaticFuncs.setMaximumRetry(maximumRetry);

		// MAX_LIST_SIZE
		int maxListSize = 150;
		try {
			maxListSize = Integer.parseInt(sMaxListSize);
			StaticFuncs.setMaxListSize(maxListSize);
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}

		try {
			StaticFuncs.setMembershipListSize(Integer.parseInt(sMemListSize));
		} catch (Exception e) {
			StaticFuncs.dbgln(e.getMessage());
		}

		boolean enableSaveView = true;
		if (sEnableSaveView != null)
			enableSaveView = Boolean.valueOf(sEnableSaveView).booleanValue();

		StaticFuncs.setAnalyticsEnableSaveView(enableSaveView);

		boolean enableAppletCache = true;
		if (sEnableAppletCache != null)
			enableAppletCache =
				Boolean.valueOf(sEnableAppletCache).booleanValue();

		StaticFuncs.setAnalyticsEnableAppletCache(enableAppletCache);

		StaticFuncs.setAnalyticsWatermark(sAnalyticsWatermark);

		boolean allowViewSourceRecords = true;
		if (sAnalyticsAllowViewSourceRecords != null)
			allowViewSourceRecords =
				Boolean
					.valueOf(sAnalyticsAllowViewSourceRecords)
					.booleanValue();
		StaticFuncs.setAnalyticsAllowViewRecords(allowViewSourceRecords);
		
		boolean bisAJC = StartupUtil.isAJC( );
	    StaticFuncs.setIsAJC( bisAJC );

		StaticFuncs.setAnalyticsAppletHeight(sAnalyticsCubeHeight);
		StaticFuncs.setAnalyticsAppletWidth(sAnalyticsCubeWidth);

		StaticFuncs.setAnalyticsBaseExpLevelName(sAnalyticsBaseExpLevelName);

		StaticFuncs.setServerQueryTimeout(serverQueryTimeout);
		StaticFuncs.setForceGC(forceGC);
		StaticFuncs.setExecuteReportWaitTime(waitTime);
		StaticFuncs.setUseJSAPIParameterPage(sUserJSAPIParameterPage);
		StaticFuncs.setEnableFacebook( sEnableFacebook );
		StaticFuncs.setFacebookBaseURL( sFacebookBaseURL );
		StaticFuncs.setDashboardSharedFolder( sDashboardSharedResources );
		
        String dashboardMode = "false";
        
        String dashboardTemplateName = StartupUtil.getDefaultInitParameter("DASHBOARD_TEMPLATE_NAME");
        if (! AcConstants.DASHBORAD_PROFILE_EXTENSION.equalsIgnoreCase( StaticFuncs.getFileExtension( dashboardTemplateName )))
        {
            String msg = "dashboard template file is not defined in web.xml";

            logger.warning( msg );
        }
        DashboardUtil.setDashboardTemplatePathFromWebDotXml( dashboardTemplateName );
		
        //even though "DASHBORD_MODE" is removed from web.xml, we still keep the logic to 
        //enable or disable dashbord.  
        dashboardMode = StartupUtil.getDefaultInitParameter("DASHBOARD_MODE");
        dashboardMode = dashboardMode == null?"true":dashboardMode;
        Utility.setDashboardMode( Boolean.parseBoolean( dashboardMode ) );
        String profilePath = StartupUtil.getDefaultInitParameter("VOLUME_PROFILE_LOCATION");
        String defServerUrl = null;
        String defVolume = null;
        String defRepositoryType = null;
        VolumeProfileManager.getInstance( profilePath, defServerUrl,  defVolume, defRepositoryType);
        
        String repositoryType = Utility.getDefaultRepositoryType();
        repositoryType = repositoryType == null ? iPortalRepository.REPOSITORY_STANDALONE:repositoryType;
        if ( !iPortalRepository.REPOSITORY_ENCYCLOPEDIA.equalsIgnoreCase( repositoryType )
                && !iPortalRepository.REPOSITORY_STANDALONE.equalsIgnoreCase( repositoryType ) )
        {
            // if somehow volumeprofile.xml does not contain default entry
            // set default repositorytype to workgroup mode
            // and set default serverurl and default volume to null
            repositoryType = iPortalRepository.REPOSITORY_STANDALONE;
            Utility.setDefaultRepositoryType( repositoryType );
            StaticFuncs.setDefaultServerUrl( "" );
            StaticFuncs.setDefaultVolume( "" );
        }

        // Set application level setting for userinfobean
        defServerUrl = StaticFuncs.getDefaultServerUrl( );
        defVolume = StaticFuncs.getDefaultVolume( );
        
        if ( !"".equals(defServerUrl) )
        {
        	UserInfoBean.setDefaultServerURL( defServerUrl );
        }
        if ( !"".equals(defVolume) )
        {
        	UserInfoBean.setDefaultVolume( defVolume );
        }
        
        String securityAdapterName = StartupUtil.getDefaultInitParameter(IPortalConsts.WEBXML_SECURITY_ADAPTER);
        Utility.setSecurityAdapterName( securityAdapterName );
        
        String installMode = StartupUtil.getDefaultInitParameter("INSTALL_MODE");
        StartupUtil.setInstallMode(installMode);
        String homepageConfigValue = StartupUtil.getDefaultInitParameter("HOME_PAGE");
        if (homepageConfigValue != null && homepageConfigValue.length() > 0 
                && !"$$Default_HOME_PAGE$$".equalsIgnoreCase( homepageConfigValue ))
        {
            homePage = homepageConfigValue;
        }
        
        String proxyURL = StartupUtil.getDefaultInitParameter("PROXY_BASEURL");
        if( proxyURL != null && proxyURL.length() > 0)
        {
        	proxyURL = proxyURL.trim();
        	StaticFuncs.setProxyBaseURL(proxyURL);
        }
		
		String defaultWorkgroupSkin = StartupUtil.getDefaultInitParameter("DEFAULT_WORKGROUP_SKIN");
		Utility.setDefaultWorkgroupSkin(defaultWorkgroupSkin);
		
		String publicFolder = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_STANDALONE_PUBLIC_FOLDER );
		Utility.setStandAlonePublicFolder( publicFolder );
		
		String homeFolder = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_STANDALONE_HOME_FOLDER );
		Utility.setStandaloneHomeFolder( homeFolder );
		
        String viewXlsInRequester = StartupUtil.getDefaultInitParameter("VIEW_XLS_IN_REQUESTER");
        if ("true".equalsIgnoreCase( viewXlsInRequester ))
        {
            StaticFuncs.setViewXlsInRequester( viewXlsInRequester );            
        }
        String essViewingFormat = StartupUtil.getDefaultInitParameter("DEFAULT_ESS_VIEWING_FORMAT");
        StaticFuncs.setDefaultEssViewingFormat( essViewingFormat );            
        
		String defaultWorkgroupRole = StartupUtil.getDefaultInitParameter("DEFAULT_WORKGROUP_FUNCTIONALITY_ROLE");
		Utility.setDefaultFunctionalityRole(defaultWorkgroupRole);
		
		StaticFuncs.dbgln(
			"COOKIE_DOMAIN\t" + CookieHandlerBean.getCookieDomain());
		StaticFuncs.dbgln(
			"SERVER_QUERY_TIMEOUT(in seconds)\t" + serverQueryTimeout / 1000);
		StaticFuncs.dbgln(
			"FORCED_GC_INTERVAL(in seconds)\t" + sForcedGCInterval);
		StaticFuncs.dbgln("MAX_CONNECTIONS_PER_SERVER\t" + proxyPoolSize);
		StaticFuncs.dbgln("CONNECTION_TIMEOUT(in seconds)\t" + connTimeOut);
		StaticFuncs.dbgln("Default Locale\t" + Locale.getDefault());
		StaticFuncs.dbgln(
			"Startup JVM's default locale language\t"
				+ defaultLocale.getLanguage());

	}



	/**
	 * set if it is deploy or product, then check if get DOC_BASE from web.xml
	 */
	private void initDocBase(ServletConfig scg ) {
		ServletContext sc = scg.getServletContext();
		
		String docWebBaseValue = StartupUtil.getDefaultInitParameter("AC_DOC_BASE");
		docWebBaseValue = docWebBaseValue == null ? "" : docWebBaseValue.trim();
		if (docWebBaseValue.length() == 0 || "$$AC_DOC_BASE$$".equalsIgnoreCase(docWebBaseValue)) 
		{
			docWebBaseValue = null;
		}
		
		boolean isDeploy = false;
		if (FeatureManagerImpl.getInstance().isProductionMode()) {
			isDeploy = true;
		}
		
		StartupUtil.setIsDeploy( isDeploy );
		
		String componentName = HelpDocBaseUtil.getComponentName();
		
		String helpBase = HelpDocBaseUtil.getDocBase(isDeploy, docWebBaseValue, componentName );
		com.actuate.iportal.utils.Utility.setHelpDocBase( helpBase);
	}
	/**
	 * Copied from FileDownloadServlet TODO remove the one in
	 * CacheDownloadServlet, we don't need that anymore but that one has member
	 * variables
	 * 
	 * @param scg
	 */
	private String initTempFolder(ServletConfig scg, String folderPath) {
        ServletContext sc = scg.getServletContext();
        String sCacheFolderPath = "";
        String sSeparator = System.getProperty("file.separator");
        String sCacheFolder = "temp";
        String sRealPath = null;
        
        String sTempFolder = folderPath == null? "": folderPath.trim();
        File f = null;
        //at this point, sTempFolder will be either empty string or a real path
        if ( sTempFolder.length() > 0 )
        {
            sTempFolder = sTempFolder.trim();
            f = new File( sTempFolder );
            if ( !f.exists() || !f.isDirectory() )
            {
                // sc.log("directory " + sTempFolder + " doesn't exist ");
                if((sTempFolder.equals( "$$Temp_Folder$$" ))||(f.isAbsolute()))
                    sRealPath = sc.getRealPath( sCacheFolder );
                else
                    sRealPath = sc.getRealPath( sTempFolder );
            }
            else
            {
                sRealPath = sTempFolder;
            }
        }
        else
        {
            sRealPath = sc.getRealPath( sCacheFolder );
        }

        if (sRealPath == null) {
            String sUserDir = System.getProperty("java.io.tmpdir");
            sTempFolder =
                sUserDir
                    + (sUserDir.endsWith(sSeparator) ? "" : sSeparator)
                    + sCacheFolder;
        } else {
            sTempFolder = sRealPath;
        }
        f = new File(sTempFolder);
        
        //f = new File(sTempFolder);
        //If the file exists and it is not a directory then generate a unique name for the temp directory   
        sc.log("Temp files will be saved to : " + sTempFolder);
        if (f.exists()) {
            if (!f.isDirectory()) {
                sTempFolder = StaticFuncs.getUniqueFile(sTempFolder);
            } else {
                sCacheFolderPath = sTempFolder;
                FileUtility.setTemporaryDirectory(new File(sCacheFolderPath));
                return sTempFolder;
            }
        }
        f = new File(sTempFolder);
        if (f.mkdirs()) {
            //we shouldn't fail at this point.
            //This is just for safety reason
            sCacheFolderPath = sTempFolder;
        }
        
        FileUtility.setTemporaryDirectory(new File(sCacheFolderPath));
        return sTempFolder;
    }


	/**
	 *
	 * @param      scg
	 */
	private void initDownloadDir(ServletConfig scg) {
		ServletContext sc = scg.getServletContext();
		//Get the web application root directory.
		String sDownloadDir = sc.getRealPath("");
		if (sDownloadDir == null) {
			//This condition should never occur.
			//However, it has been kept just in case some servlet container does not implement the api correctly.
			sDownloadDir = System.getProperty("user.dir");
		}
		//Create a downloads directory under this directory.
		String sSeparator = System.getProperty("file.separator");
		sDownloadDir += (sDownloadDir.endsWith(sSeparator) ? "" : sSeparator)
			+ "downloads";
		File f = new File(sDownloadDir);
		if (f.exists()) //Check whether the directory exists
			{
			//If the file exists. Check that it is a directory
			if (!f.isDirectory()) {
				//If it isn't then set the location to the current user directory.
				sDownloadDir = System.getProperty("user.dir");
			}
		} else {
			//If not try creating the directory.
			if (!f.mkdirs()) {
				//If we are unsuccessful in creating the directory. Set the path to the current user directory.
				sDownloadDir = System.getProperty("user.dir");
			}
		}
	}
	
	/**
	 * Unused method from base class
	 * @param      dph
	 * @param      userMap
	 * @return	   HttpResponse
	 * @exception  ServletException
	 */
	protected HttpResponse submitRequest(
        HttpServletRequest hrq, 
		DefaultParamHandler dph,
		UserMap userMap)
		throws ServletException {
		return null;
	}

	/**
	 * getPlatformDir will retrieve the value of BIRT_PLATFORM_LOCATION from web.xml.  If the location specified by
	 * the web.xml does not exist or it is not a directory, getPlatformDir will return null.  
	 * The caller should use the default behavior before the introduction of BIRT_PLATFORM_LOCATION
	 * for locating the platform directory.
	 * 
	 * @param servletContext
	 * @return
	 */
	private static String getBIRTEngineHome(ServletContext servletContext)
	{		
		String platformPath = IPortalConsts.BIRT_Engine_Home;    

		// For war file, BIRT home can only be "/WEB-INF/platform".
		// It cannot be validated by calling servletContext.getRealPath().
		URL resourceUrl = null;
		try 
		{
			resourceUrl = servletContext.getResource(platformPath);
		} 
		catch (MalformedURLException e) 
		{
			resourceUrl = null;
		}
				
		if ( resourceUrl == null )
		{
			String path = servletContext.getRealPath(platformPath);
			if ( !isPathValidDirectory(path))
			{
				platformPath = IPortalConsts.ENTERPRISE_WINDOWS_BIRT_Engine_Home;
				if ( !OsUtil.isWindowsOS() )
				{
					platformPath = IPortalConsts.ENTERPRISE_UNIX_BIRT_Engine_Home;
				}
				
				path = servletContext.getRealPath(platformPath);
				if ( !isPathValidDirectory( path ) )
				{
					logger.severe( "Cannot resolve BIRT engine home: " + platformPath );					
				}
				else
				{
					platformPath = path;
				}
			}
			else
			{
				platformPath = path;
			}
		}
        return platformPath;
	}

    private static boolean isPathValidDirectory(String path) 
    {
    	if (path == null)
    	{
    		return false;
    	}
    	
    	File f = null;
    	f = new File(path);
		if (!f.exists() || !f.isDirectory()) 
		{
			return false;
		}
		return true;
	}

    /*
     * TED 22753
     * For IC embedded in iServer, START_JREM is false and IC won't start JREM
     * BRS will start JREM on-demand, in which case we need handle concurrency issue  
     */
    static private Boolean jremStarted =  Boolean.valueOf(false);
	public static synchronized void startJREM( ServletContext servletContext ) 
    {
        	if ( jremStarted )
        	{
        		return;
        	}

            ReportEngineManager jrem = ReportEngineManager.getInstance();
        	// Start JREM
            try
            {
                String jremRoot = IPortalConsts.JREM_ROOT;
                logger.warning( "JREM Root has been resolved to: " + jremRoot );

                jrem.setJREMRoot( jremRoot );
                
                String birtEngineHome = getBIRTEngineHome(servletContext);            
                
                // Get and set BIRT resource path
                String resourcePath = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_RESOURCE_PATH );
                // check relative path for compatibility of Actuate BIRT Viewer
                resourcePath = BirtViewerUtil.resolveRelativePath( resourcePath, servletContext);            
                VolumeManager.getInstance().setBIRTResourcePath( resourcePath );
                
                //Get and set BIRT script library path
                String scriptLibPath = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_SCRIPT_LIB_PATH );
                scriptLibPath = BirtViewerUtil.resolveRelativePath( scriptLibPath, servletContext);            
                VolumeManager.getInstance().setBIRTScriptLibPath( scriptLibPath );
                
                jrem.setVolumeManager( VolumeManager.getInstance() );
                
                ReportEngineConfig jremConfig = new ReportEngineConfig();
                jremConfig.setEngineName( "" );
                jremConfig.setServletContext( servletContext );
                Properties jremProp = new Properties();

                // Configuration for JREM BIRT report engine
                ReportEngineConfig birtConfig = new ReportEngineConfig();
                birtConfig.setEngineName( "birt" );
                Properties birtProp = new Properties();
                
                // Configuration for JREM ESS report engine
                ReportEngineConfig essConfig = new ReportEngineConfig();
                essConfig.setEngineName( "ess" );
                
                // Turn on the BIRT archive manager physical file modification check
                birtProp.setProperty(JREMConstants.AC_JREM_BIRT_ARCHIVE_CHECK_MODIFICATION, "true");
                
                String engineCascadingStyle = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_HTMLRENDEROPTION_ENGCASSTYLE );
                if(engineCascadingStyle != null)
                {
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_HTMLRENDEROPT_ENGINECASCADINGSTYLE, engineCascadingStyle );
                }
                
                String duration = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JAVAREPORTAPI_IMGCACHE_EXPIREINSECONDS );
                birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ENGINE_ROOT, birtEngineHome );
                birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CACHE_EXPIRE_IN_SECONDS, duration );
                
                String birtJDBCConnectionPoolSize = StartupUtil.getDefaultInitParameter(IPortalConsts.WEBXML_BIRT_JDBC_CONNECTION_POOL_SIZE);
    			String birtJDBCConnectionPoolTimeoutSec = StartupUtil.getDefaultInitParameter(IPortalConsts.WEBXML_BIRT_JDBC_CONNECTION_POOL_TIMEOUT);    			
    			String birtJDBCConnectionValidationIntervalSec = StartupUtil.getDefaultInitParameter(IPortalConsts.WEBXML_BIRT_JDBC_CONNECTION_VALIDATION_INVERVAL);
    			
    			if( !LicenseManager.isDeploymentKitAllowed() )
    			{
    				// Setting the pool size to 0 disables the connection pooling
    				birtJDBCConnectionPoolSize = "0";
    			}
    			
    			if( birtJDBCConnectionPoolSize != null )
    			{
    				birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CONNECTION_POOL_SIZE, birtJDBCConnectionPoolSize );
    			}
    			if( birtJDBCConnectionPoolTimeoutSec != null )
    			{
    				birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CONNECTION_POOL_TIMEOUT, birtJDBCConnectionPoolTimeoutSec );
    			}
    			if( birtJDBCConnectionValidationIntervalSec != null )
    			{
    				birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CONNECTION_VALIDATION_INTERVAL, 
    						birtJDBCConnectionValidationIntervalSec );
    			}
    			
                String sTemp = null;
                // In-memory archive: set these options if licensed
                if(LicenseManager.isDeploymentKitAllowed())
                {
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_MAX_MEMORY_SIZE_PER_ARCHIVE );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_MAX_MEMORY_PER_ARCHIVE, sTemp );
                	}
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_ARCHIVE_MEMORY_TOTALSIZE );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ARCHIVE_MEMORY_TOTALSIZE, sTemp );
                	}
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_REPORT_DESIGN_CACHE_TIMEOUT );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_DESIGN_CACHE_TIMEOUT, sTemp );
                	}
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_REPORT_DESIGN_CACHE_TOTAL_NUMBER_OF_ENTRIES );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_DESIGN_CACHE_TOTAL_NUMBER_OF_ENTRIES, sTemp );
                	}
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_REPORT_PAGE_COUNT_CACHE_ENABLED );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_PAGE_COUNT_CACHE_ENABLED, sTemp );
                	}
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_REPORT_DOCUMENT_CACHE_ENABLED );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_DOCUMENT_CACHE_ENABLED, sTemp );
                	}            	                	
                	sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_ARCHIVE_AUTO_CLOSE_ENABLED );
                	if ( sTemp != null )
                	{
                		birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ARCHIVE_AUTO_CLOSE_ENABLED, sTemp );
                	}            
                }
                // if not licensed set these options to zero
                else
                {
                	birtProp.setProperty( JREMConstants.AC_JREM_BIRT_MAX_MEMORY_PER_ARCHIVE, "0" );
                	birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ARCHIVE_MEMORY_TOTALSIZE, "0" );
                	birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_DESIGN_CACHE_TIMEOUT, "0" );
                	birtProp.setProperty( JREMConstants.AC_JREM_BIRT_REPORT_DESIGN_CACHE_TOTAL_NUMBER_OF_ENTRIES, "0" );
                	birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ARCHIVE_AUTO_CLOSE_ENABLED, "true" );
                }

                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_PRELOAD_ENGINE_LIST );
                if( sTemp != null )
                {
                	jremProp.setProperty( JREMConstants.AC_JREM_PRELOAD_ENGINE_LIST, sTemp );
                }            
                
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_THREADPOOL_SYNC_TASKQUEUE_TIMEOUT );
                int queueTimeout = 0; 
                if ( sTemp != null )
                {
                    queueTimeout = Integer.parseInt( sTemp );
                    jremProp.setProperty( JREMConstants.AC_JREM_TASK_QUEUE_TIMEOUT, sTemp );
                    logger.config( "Threadpool task queue timeout is "+queueTimeout + " seconds");
                    
                }
                int taskRuntimeTimeout = 0;
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_THREADPOOL_MAXSYNC_TASK_RUNTIME );
                if ( sTemp != null )
                {
                    taskRuntimeTimeout = Integer.parseInt( sTemp );
                    jremProp.setProperty( JREMConstants.AC_JREM_TASK_SYNC_GENERATION_TIMEOUT, sTemp );
                    logger.config( "Synchronous report generation timeout is "+ taskRuntimeTimeout + " seconds");
                }
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_TRANSIENT_STORE_TIMEOUT_MIN );
                if ( sTemp != null )
                {
                    int archiveFileTimeout = Integer.parseInt( sTemp ) * 60;  // seconds
                    if((archiveFileTimeout ) <  (queueTimeout + taskRuntimeTimeout + gracePeriodForThreadpoolTimeouts))
                    {
                        archiveFileTimeout = queueTimeout + taskRuntimeTimeout + (gracePeriodForThreadpoolTimeouts ) ;
                    }
                    logger.config( "Archive file timeout is "+ archiveFileTimeout + " seconds");
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_ARCHIVE_FILE_TIMEOUT, String.valueOf( archiveFileTimeout ) );
                }
                
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_TRANSIENT_ARCHIVEFILECACHE_TIMEOUT_SECONDS );
                if ( sTemp != null )
                {
                    int transientArchiveFileTimeout = Integer.parseInt( sTemp );  // seconds
                    if((transientArchiveFileTimeout ) <  (queueTimeout + taskRuntimeTimeout + gracePeriodForThreadpoolTimeouts))
                    {
                    	transientArchiveFileTimeout = queueTimeout + taskRuntimeTimeout + (gracePeriodForThreadpoolTimeouts ) ;
                    }
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_TRANSIENT_ARCHIVE_FILE_TIMEOUT, String.valueOf( transientArchiveFileTimeout ) );
                }
                
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_PERSISTENT_ARCHIVEFILECACHE_TIMEOUT_SECONDS );
                if ( sTemp != null )
                {
                    int persistentArchiveFileTimeout = Integer.parseInt( sTemp );  // seconds
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_PERSISTENT_ARCHIVE_FILE_TIMEOUT, String.valueOf( persistentArchiveFileTimeout ) );
                }
                
                            
                // BIRT data resultset
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_DATA_RESULTSET_BUFFER_SIZE );
                if ( sTemp != null )
                {
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_DTE_RESULTSET_BUFFER_SIZE, sTemp );
                }
                
                // BIRT Chart
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_CHART_MAX_ROWS );
                if ( sTemp != null )
                {
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CHART_MAX_ROWS, sTemp );
                }
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_CHART_MAX_VARIABLE_SIZE );
                if ( sTemp != null )
                {
                    birtProp.setProperty( JREMConstants.AC_JREM_BIRT_CHART_MAX_VARIABLE_SIZE, sTemp );
                }

                // BIRT render option and emitter id mapping
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_RENDER_FORMAT_EMITTER_ID_MAPPING );
                if ( sTemp != null )
                {
                	birtProp.setProperty(JREMConstants.AC_JREM_BIRT_RENDER_FORMAT_EMITTER_ID_MAPPING, sTemp);
                }
                
                // JREM thread pool
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_THREAD_POOL_SIZE );
                if ( sTemp != null )
                {
                    jremProp.setProperty( JREMConstants.AC_JREM_THREAD_POOL_SIZE, sTemp );
                }
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_TASK_QUEUE_SIZE );
                if ( sTemp != null )
                {
                    jremProp.setProperty( JREMConstants.AC_JREM_TASK_QUEUE_SIZE, sTemp );
                }  
               
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_JREM_THREADPOOL_MONTHREAD_POLLINGINERVAL );
                if ( sTemp != null )
                {
                    jremProp.setProperty( JREMConstants.AC_JREM_MONITOR_THREAD_SLEEP_INVERVAL, sTemp );
                }            
                 
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_BIRT_ALLOW_DYNAMIC_RESOURCE_PATH );
                if ( sTemp != null )
                {
            		birtProp.setProperty( JREMConstants.JREM_BIRT_ALLOW_DYNAMIC_RESOURCE_PATH, sTemp );
                }
                
                ClassLoader appClassLoader = (ClassLoader)servletContext.getAttribute( IPortalConsts.BIRT_CLASS_LOADER );
                if ( appClassLoader != null )
                {
                	birtProp.put( JREMConstants.JREM_BIRT_CLASS_LOADER, appClassLoader );
                }
                
                sTemp = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_ALLOW_TRANSIENT_SECURITY_ID );
                if ( sTemp != null )
                {
                    birtProp.setProperty( JREMConstants.JREM_ALLOW_TRANSIENT_SECURITY_ID, sTemp );
                }   
                
				String workgroupProductMode = StartupUtil.getDefaultInitParameter( StartupUtil.WEBXML_WORKGROUP_PRODUCT_MODE );
				if ( workgroupProductMode != null )
				{
					String productMode = JREMConstants.AC_WORKGROUP_PRODUCT_MODE_AJC;
					if ( JREMConstants.AC_WORKGROUP_PRODUCT_MODE_BRDPRO
							.compareToIgnoreCase( workgroupProductMode ) == 0 )
					{
						productMode = JREMConstants.AC_WORKGROUP_PRODUCT_MODE_BRDPRO;
					}
					
					birtProp.setProperty(
							JREMConstants.AC_WORKGROUP_PRODUCT_MODE,
							productMode );
				}
                
                File tmpFolder = FileUtility.getTemporaryDirectory();
                String tmpFolderPath = tmpFolder.getAbsolutePath()
                        + System.getProperty( "file.separator" ) + "BirtEngineTmp";
                File birtEngineTempFolder = new File (tmpFolderPath);
                try
                {
                	birtEngineTempFolder.mkdirs();
                }
                catch( SecurityException e )
                {
                	logger.warning( "Failed to create directory " + tmpFolderPath + " for BirtEngineTmp");
                }
                
                birtProp.setProperty( JREMConstants.JREM_BIRT_ENGINE_TMP_FOLDER, tmpFolderPath );
                birtConfig.setProperties( birtProp );
                jremConfig.setProperties( jremProp );
                
                ArrayList alJremConfig = new ArrayList();
                alJremConfig.add( jremConfig );
                alJremConfig.add( birtConfig );
                alJremConfig.add( essConfig );
                
                //set the working folder to system proeprty 
                String workingPath =  StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_STANDALONE_REPOSITORY_PATH);
                workingPath = BirtViewerUtil.resolveRelativePath( workingPath, servletContext);    
             
                System.setProperty( "birt.viewer.working.path", workingPath );    
                
                // use iPortal's JUL log level
                jrem.SetInitLog( false );
                jrem.startup( alJremConfig );
            }
            catch ( Throwable t )
            {
                t.printStackTrace();
            }
        	
        	// Set the flag
        	jremStarted = true;
    }

    protected void initializeWorkSpace( ServletContext servletContext )
    {

    	String workDir = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_TRANSIENT_STORE_PATH );
        
        String sSeparator = System.getProperty("file.separator");
        String systemTmpDir = System.getProperty("java.io.tmpdir");
        String sTransientDir = "transientStore";
        String sRealPath = null;
       
        boolean bUsingUserDir=false;
        
        File f = null;
        if ((workDir != null)&&( !(workDir.trim().length() == 0))) {
        	workDir = workDir.trim();
        	// use the user specified folder whenever the workDir's length > 0
            f = new File(workDir);
            if (!f.exists() || !f.isDirectory()) {
            	          
            	// if it is a relative path, try to get real path.
                if( !f.isAbsolute() )
                {
                    sRealPath = servletContext.getRealPath(workDir);
                    sTransientDir = workDir;
                }
            }
            else{
                sRealPath = workDir;
            }
        }
        else{
        	// if the user doesn't specify in web.xml, use default
            sRealPath = servletContext.getRealPath(sTransientDir);
        }

        if (sRealPath == null) {
           workDir = systemTmpDir
                        + (systemTmpDir.endsWith(sSeparator) ? "" : sSeparator
                        		+ sTransientDir );
	    } else {
	    	workDir = sRealPath;
	    }
        
        //If the file exists and it is not a directory then generate a unique name for the temp directory   
	    servletContext.log("Transient files will be saved to : " + workDir);
        
        File tmpDir = new File( workDir );
        boolean useSystemTemp = false;        
        
        if ( !tmpDir.exists() )
        {   
        	// Cannot make the directory
        	if( !tmpDir.mkdir() )
        	{
        		logger.warning("Failed to create the transient folder: " + tmpDir );
        		useSystemTemp = true;
        	}
        }
        else
        {
        	// It's a file instead of folder
        	if( tmpDir.isFile())
        	{
        		logger.warning("Configured transient folder is not of directory type: " + tmpDir );
        		useSystemTemp = true;
        	}
        	// A read-only folder
        	else if( !tmpDir.canWrite() )
        	{
        		logger.warning("Configured transient folder is read-only: " + tmpDir );
        		useSystemTemp = true;
        	}        	       	
        }
        
        if( useSystemTemp )
        {        	
            workDir = systemTmpDir
            	+ (systemTmpDir.endsWith(sSeparator) ? "" : sSeparator
            		+ sTransientDir );
            
    		logger.warning("Using system temp folder '" + workDir + "' as the transient store folder");
    		
    		tmpDir = new File( workDir );
    		try
    		{
    			tmpDir.mkdir();
    		}
    		catch ( SecurityException e )
    		{
    			logger.warning("Failed to create directory: " + workDir );
    		}
    		
        }
        
    	TransientManager transientManager = TransientManager.getInstance();
        String maxSize = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_TRANSIENT_STORE_MAX_SIZE_KB );
        try
        {
            transientManager.initTransientManager( workDir, Integer.valueOf( maxSize ).intValue() );
        }
        catch ( TransientConfigurationException e )
        {
            e.printStackTrace();
        }

        // Set transient item timeout
        String tsTimeout = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_TRANSIENT_STORE_TIMEOUT_MIN );         
        transientManager.setTransientStoreTimeout( Integer.valueOf( tsTimeout ).intValue()*60 );
        logger.config( "Transient item timeout is "+tsTimeout + " minutes");
        // Set cache item timeout
        String cacheTimeout = StartupUtil.getDefaultInitParameter( IPortalConsts.WEBXML_REPOSITORY_CACHE_TIMEOUT_SEC );
        transientManager.setCacheTimeout( Integer.valueOf( cacheTimeout ).intValue() );
    }
    
    public static String getHomePage()
    {
        return homePage;
    }
}
