package com.actuate.erni.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletResponse;
import javax.servlet.ServletResponseWrapper;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

public class HttpServletResponseAbstractRedirector extends ServletResponseWrapper implements HttpServletResponse
{
	protected final static String DEFAULT_ENCODING = "utf-8";	

	protected OutputStream output;
	protected ServletOutputStream interceptor;
	protected PrintWriter writer;
	public HttpServletResponseAbstractRedirector( ServletResponse response )
	{
		super( response );
	}
	
	public void addCookie( Cookie cookie )
	{
	}

	public void addDateHeader( String name, long date )
	{
	}

	public void addHeader( String name, String value )
	{
	}

	public void addIntHeader( String name, int value )
	{
	}

	public boolean containsHeader( String name )
	{
		return false;
	}

	public String encodeRedirectURL( String url )
	{
		return null;
	}

	public String encodeRedirectUrl( String url )
	{
		return null;
	}

	public String encodeURL( String url )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String encodeUrl( String url )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void sendError( int sc ) throws IOException
	{
		// TODO Auto-generated method stub
		
	}

	public void sendError( int sc, String msg ) throws IOException
	{
		// TODO Auto-generated method stub
		
	}

	public void sendRedirect( String location ) throws IOException
	{
		// TODO Auto-generated method stub
		
	}

	public void setDateHeader( String name, long date )
	{
		// TODO Auto-generated method stub
		
	}

	public void setHeader( String name, String value )
	{
		// TODO Auto-generated method stub
		
	}

	public void setIntHeader( String name, int value )
	{
		// TODO Auto-generated method stub
		
	}

	public void setStatus( int sc )
	{
		// TODO Auto-generated method stub
		
	}

	public void setStatus( int sc, String sm )
	{
		// TODO Auto-generated method stub
		
	}

	public void flushBuffer( ) throws IOException
	{
		this.output.flush();
	}

	public int getBufferSize( )
	{
		return 0;
	}

	public String getCharacterEncoding( )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String getContentType( )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public Locale getLocale( )
	{
		// TODO Auto-generated method stub
		return null;
	}

	public ServletOutputStream getOutputStream( ) throws IOException
	{
		return this.interceptor;
	}

	public PrintWriter getWriter( ) throws IOException
	{
		return this.writer;
	}

	public boolean isCommitted( )
	{
		// TODO Auto-generated method stub
		return false;
	}

	public void reset( )
	{
		// TODO Auto-generated method stub
		
	}

	public void resetBuffer( )
	{
		// TODO Auto-generated method stub
		
	}

	public void setBufferSize( int size )
	{
		// TODO Auto-generated method stub
		
	}

	public void setCharacterEncoding( String charset )
	{
		// TODO Auto-generated method stub
		
	}

	public void setContentLength( int len )
	{
		// TODO Auto-generated method stub
		
	}

	public void setContentType( String type )
	{
		// TODO Auto-generated method stub
		
	}

	public void setLocale( Locale loc )
	{
		// TODO Auto-generated method stub
		
	}
	
	public void release( )
	{
		this.writer.flush();
		try
		{
			this.interceptor.flush();
		}
		catch ( IOException e )
		{
		}
		try
		{
			this.output.flush();
		}
		catch ( IOException e )
		{
		}
		this.writer.close();
		try
		{
			this.interceptor.close();
		}
		catch ( IOException e )
		{
		}
		try
		{
			this.output.close();
		}
		catch ( IOException e )
		{
		}
		
	}

	public String getHeader(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<String> getHeaderNames() {
		// TODO Auto-generated method stub
		return null;
	}

	public Collection<String> getHeaders(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getStatus() {
		// TODO Auto-generated method stub
		return 0;
	}
}
