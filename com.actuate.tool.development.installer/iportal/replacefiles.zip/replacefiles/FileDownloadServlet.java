package com.actuate.reportcast.servlets;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.actuate.activeportal.beans.UserInfoBean;
import com.actuate.activeportal.utils.Utility;
import com.actuate.iportal.auth.IPortalAuth;
import com.actuate.iportal.common.IPortalConsts;
import com.actuate.iportal.portlet.helper.HttpRequestParamHandler;
import com.actuate.iportal.session.iPortalRepository;
import com.actuate.iportal.session.iPortalSession;
import com.actuate.reportcast.dstruct.ErrorObject;
import com.actuate.reportcast.dstruct.FileFolder;
import com.actuate.reportcast.dstruct.FileType;
import com.actuate.reportcast.exceptions.HttpException;
import com.actuate.reportcast.exceptions.SoapFaultException;
import com.actuate.reportcast.resources.ResourceManager;
import com.actuate.reportcast.utils.AcRequestHandlerBean;
import com.actuate.reportcast.utils.DefaultParamHandler;
import com.actuate.reportcast.utils.DefaultSoapHandler;
import com.actuate.reportcast.utils.IPortalFileTypeManager;
import com.actuate.reportcast.utils.FileTypes;
import com.actuate.reportcast.utils.HttpRequest;
import com.actuate.reportcast.utils.HttpResponse;
import com.actuate.reportcast.utils.ServerResponseParser;
import com.actuate.reportcast.utils.SinglePart;
import com.actuate.reportcast.utils.SoapBody;
import com.actuate.reportcast.utils.SoapEnvelope;
import com.actuate.reportcast.utils.SoapHeader;
import com.actuate.reportcast.utils.SoapParser;
import com.actuate.reportcast.utils.StaticFuncs;
import com.actuate.reportcast.utils.UserMap;
import com.actuate.repository.file.IInputRepositoryFile;
import com.actuate.repository.file.RepositoryFileException;
import com.actuate.repository.file.RepositoryFileInvalidItemException;

/**
 * This servlet is used to download a file object from the encyclopaedia. It is a
 * subclass of AcServlet. Internally, it submits the appropriate SOAP Request API
 * to retrieve a file object from the server. The response contains multiple
 * mime-parts with chunked data. The attachment part will be processed using the SinglePart
 * utility class and the content is streamed back to the browser. The mime-type for the
 * attachment is set depending on the content type property of the file type of the file being
 * downloaded. If the showDownloadDialog parameter is passed as true, the file will always be
 * downloaded to the client machine. This servlet also supports downloading composite
 * documents (row files).
 *
 * @author  Actuate Corporation
 * @version 1.0
 */
public class FileDownloadServlet extends AcServlet
{
    /**	*/
    static final Hashtable htFiles = new Hashtable();

    // Commented out as this variable is currently not used - sudish
    //private long lMaxLifeSpan = 86400000;

	/**	*/
    private String sCacheFolder = "temp";
    /** */
    private boolean bUsingUserDir = false;
    /**	*/
    static String sCacheFolderPath = null;
    /**	*/
    static final String sSeparator = System.getProperty("file.separator");
    
    public static final long lClearInterval = 5 * 60 * 60 * 1000;
    private long lLastClearTime = System.currentTimeMillis();

	/**
	 *
	 * @param      sc
	 * @exception  ServletException
	 */
	public void init(ServletConfig sc) throws ServletException
	{
        super.init(sc);
        initialiseTempFolder(sc);
    }

    /**
     *
     * @param      scg
     */
    private void initialiseTempFolder(ServletConfig scg)
    {
		ServletContext sc = scg.getServletContext();
		String sTempFolder = (sc.getInitParameter("TEMP_FOLDER_LOCATION"));
		File f = null;
		if (sTempFolder != null)
		{
			sTempFolder = sTempFolder.trim();
			f = new File(sTempFolder);
			bUsingUserDir = true;
			if ( !f.exists() || !f.isDirectory() )
			{
	            sc.log("directory " + sTempFolder + " doesn't exist ");
				sTempFolder = null;
				bUsingUserDir = false;
        	}
		}

		if (sTempFolder == null)
		{
			String sRealPath = sc.getRealPath("");

			if (sRealPath == null)
			{
				bUsingUserDir = true;
				String sUserDir = System.getProperty("java.io.tmpdir");
				sTempFolder = sUserDir + (sUserDir.endsWith(sSeparator)?"":sSeparator) + sCacheFolder;
			}
			else
			{
				sTempFolder = sRealPath + sSeparator + sCacheFolder;
			}
			f = new File(sTempFolder);
		}
        //f = new File(sTempFolder);
        //If the file exists and it is not a directory then generate a unique name for the temp directory
        if ( f.exists() )
        {
            if ( !f.isDirectory() )
            {
                sTempFolder = StaticFuncs.getUniqueFile(sTempFolder);
			}
            else
            {
                sCacheFolderPath = sTempFolder;
                return;
            }
        }
        f = new File(sTempFolder);
        if ( f.mkdirs() )
        {
            //we shouldn't fail at this point.
            //This is just for safety reason
            sCacheFolderPath = sTempFolder;
        }
    }


    /**
     *
     * @param      sFQName
     * @return	   int
     */

    /* Commented out as this method is not currently being used - Sudish

    private static final int getPathDepth(String sFQName)
    {
        int iDepth = 0;
        for (int i = 1; i < sFQName.length(); i++)
        {
            if (sFQName.charAt(i) == '/')
            {
				iDepth++;
			}
		}
        return iDepth;
    }
    */
    
    private final void clearCache()
    {
    	synchronized(htFiles)
    	{
    		//Clear the cache if the differnce between the last time it was cleared
    		//and the current time is > the clear interval
    		if(( System.currentTimeMillis() - lLastClearTime) > lClearInterval)
    		{
    			Enumeration e = htFiles.keys();
    			while(e.hasMoreElements())
    			{
    				String sKey = (String)e.nextElement();
    				CachedFile cf = (CachedFile)htFiles.get(sKey);
    				if( (System.currentTimeMillis() - cf.getLastUpdateTime()) >= lClearInterval)
    				{
    					//If the file has been lying around for more than the interval specified
    					//delete the file.
			            File f = new File(sCacheFolderPath + sSeparator + cf.getName());
			            synchronized(cf)
			            {
				            deleteFile(f);
			            }
    				}
    			}
				lLastClearTime = System.currentTimeMillis();
    		}
    	}
    }
    
    public static final void deleteFile(File f)
    {
    	if(f == null)
    	{
    		return;
    	}

    	//If the file is a directory then delete its contents
    	if(f.isDirectory())
    	{
    		//get the list of files in this directory and delete them one by one
    		File[] files = f.listFiles();
    		if(files != null)
    		{
	    		for(int n = 0; n < files.length; n++)
	    		{
	    			deleteFile(files[n]);
	    		}
    		}
    	}
    	
    	//Now finally delete this file
    	f.delete();
    }
    
    /**
     *
     * @param      request
     * @param      response
     * @param      userMap
     * @param      dph
     * @exception  ServletException
     * @exception  IOException
     */
    protected void handleServletRequest(HttpServletRequest request, HttpServletResponse response, UserMap userMap, DefaultParamHandler dph) throws ServletException, IOException
	{
		//Clear the cache
		clearCache();
        if (request.getAttribute("objectId") != null)
        {
            request.setAttribute("fileid", request.getAttribute("objectId"));
		}

        String sContextPath = request.getContextPath();
        String[][] saLegalParameters =
		{
			{ "fileid", "" },//objectID
			{ "name", "" }, //Objectname (filename)
			{ "version", "" }, // versionID
			{ "outputFileName", "" }, // outputName
			{ "outputType", "" }, // outputType
            { "returnContents", "false" }, //true if the contents of a compound document are to be extracted.
            { "connectionHandle", "" } //
		};

		String[] saRequiredParameters = {};
		String[][][] saConditionalParameters = { { {"fileid"}, {"name"} } };
        String sFileIdentifier = null;
		try
		{

            if (request.getAttribute("source.servlet") != null)
            {
                String sConnectionHandle = (String) request.getAttribute("connectionHandle");
                String sFileID = ((Integer) request.getAttribute("objectId")).toString();
                String sOutputFileType = (String) request.getAttribute("outputFileType");
                String sOutputFileName = (String) request.getAttribute("outputFileName");
                String sDecomposeCompoundDoc = (String) request.getAttribute("returnContents");
                String sPersistent = (String) request.getAttribute("persistent");

                dph.updateParameter("persistent", sPersistent);
                dph.updateParameter("connectionhandle", sConnectionHandle);
                dph.updateParameter("fileid", sFileID);
                dph.updateParameter("outputType", sOutputFileType);
                dph.updateParameter("outputFileName", sOutputFileName);
                dph.updateParameter("name", sOutputFileName);
                dph.updateParameter("returnContents", sDecomposeCompoundDoc);
            }
            else
            {
            	if ( request.getSession().getAttribute("connectionHandle") != null )
            	{
					dph.updateParameter("connectionHandle", (String) request.getSession().getAttribute("connectionHandle"));
            	}
            	
				if ( request.getSession().getAttribute("saveoutput") != null )
				{
					dph.updateParameter("saveoutput", (String) request.getSession().getAttribute("saveoutput"));
				}
            	
				if ( request.getSession().getAttribute("fileid") != null )
				{
					dph.updateParameter("fileid", (String) request.getSession().getAttribute("fileid"));
				}
				
				if ( request.getSession().getAttribute("name") != null )
				{
					dph.updateParameter("name", (String) request.getSession().getAttribute("name"));
				}
				
				if ( request.getSession().getAttribute("outputFileName") != null )
				{
					dph.updateParameter("outputFileName", (String) request.getSession().getAttribute("outputFileName"));
				}
				
				if ( request.getSession().getAttribute("outputType") != null )
				{
					dph.updateParameter("outputType", (String) request.getSession().getAttribute("outputType"));
				}
            }
            
			updateInternalProperties(request, saLegalParameters, saRequiredParameters, saConditionalParameters, userMap, dph);            

            final boolean bDownload = (dph.getParameter("showDownloadDialog") != null)
            							|| (dph.getParameter("connectionhandle") != null) ;
            
            //Get the file identifier to look up in the hashtable
            sFileIdentifier = getFileIdentifier(dph, userMap);

            //If the file is supposed to be downloaded then we don't need to check whether it is cached
            //Download the file again
            if(!bDownload)
            {
	            if (sFileIdentifier != null )
	            {
	                //Now that we have the identifier
	                //Get this file from the Hashtable if it exists.
	                String sRedirectURL = null;
					if (!bUsingUserDir)
	                {
	                	sRedirectURL = getRedirectURL(sFileIdentifier, null);
					}
					else
					{
						String sCachedFilePath = getCachedFilePath(sFileIdentifier, null);
						if (sCachedFilePath != null)
						{
							//sRedirectURL = request.getRequestURI().substring(request.getContextPath().length(), request.getRequestURI().lastIndexOf("/")) + "/CacheDownload" + "/" + sCachedFilePath ;
							sRedirectURL =  "/servlet/CacheDownload" + "/" + sCachedFilePath ;
						}
					}
	
	                //If the redirectURL is not null then send a redirect
	                if ( sRedirectURL != null )
	                {
	                    //Integer iPD = (Integer) request.getAttribute("pathDepth");
	                    //int iDepth = (iPD == null) ? 0 : iPD.intValue();
	                    //for (int i = 0; i < iDepth; i++) sRedirectURL = "../" + sRedirectURL;
	                    Utility.processRedirect(getServletContext(), request, response, sRedirectURL, null);
	                    return;
	                }
	            }
            }
        }
		catch (SoapFaultException sfe)
		{
            //sfe.printStackTrace();
            try
            {
    			response.reset();
			}
			catch (IllegalStateException lse)
			{
				StaticFuncs.error(FileDownloadServlet.class.getName(), lse.toString(), lse);
				/* QUIETLY SUPPRESS */
			}
            //sfe.printStackTrace();

			ErrorObject eo = sfe.getErrorObject();
			if (dph != null)
			{
				String s = (dph.exists("id") ? dph.getParameter("id") : dph.getParameter("name"));
				if (s != null)
				{
					eo.setProperty("item", s);
				}
			}

			eo.setProperty("class", getClass().getName());
			eo.setProperty("function", "processResponse");
            eo.setProperty("clienterrsource", "Servlet");
			eo.setProperty("clientrequest", "DownloadFile");
			eo.setProperty("operation", "Download a file"); //i18n
			sendErrorRedirect(request, response, "/iportal/activePortal/errors/error.jsp", eo);
		}
		catch (Exception ex)
		{
            //ex.printStackTrace();
            try
            {
    			response.reset();
			}
			catch (IllegalStateException lse)
			{
				StaticFuncs.error(FileDownloadServlet.class.getName(), lse.toString(), lse);
				/* QUIETLY SUPPRESS */
			}

            ErrorObject eo = new ErrorObject();
			if (dph != null)
			{
				String s = (dph.exists("id")? dph.getParameter("id"):dph.getParameter("name"));
				if (s != null)
				{
					eo.setProperty("item", s);
				}
			}

			eo.setProperty("class", getClass().getName());
            eo.setProperty("errorcode", StaticFuncs.getErrorCode("JSRVLT_", getClass(), "processResponse"));
			eo.setProperty("function", "processResponse");
            eo.setProperty("clienterrsource", "Servlet");
			eo.setProperty("clientrequest", "downloadFile");
			eo.setProperty("operation", "Download a file"); //i18n
            eo.setClientException(ex);
			sendErrorRedirect(request, response, "/iportal/activePortal/errors/error.jsp", eo);
		}

        //At this point we know that the file is not cached.
        //So we have to download it.
        FileDownloader fDownload = new FileDownloader();
        fDownload.downloadFile(this, request, response, userMap, dph);
        ErrorObject eo = fDownload.getError();

        //Once it is downloaded successfully
        //We have to check again as to whether it has been cached.
        if ( eo == null )
        {
            CachedFile cf = fDownload.getCachedFile();
            if ( cf != null )
            {
                String sRedirectURL = null;
                //if it has been cached then generate the redirect url and send it again
                if (!bUsingUserDir)
                {
                	sRedirectURL = getRedirectURL(null, cf);
				}
				else
				{
					String sCachedFilePath = getCachedFilePath(null, cf);
					if (sCachedFilePath != null)
					{
						//sRedirectURL = request.getRequestURI().substring(request.getContextPath().length(), request.getRequestURI().lastIndexOf("/")) + "/CacheDownload" + "/" + sCachedFilePath ;
						sRedirectURL =  "/servlet/CacheDownload" + "/" + sCachedFilePath ;
						
					}
				}

                //If the redirectURL is not null then send a redirect
                if (sRedirectURL != null)
                {
                    //Integer iPD = (Integer) request.getAttribute("pathDepth");
                    //int iDepth = (iPD == null) ? 0 : iPD.intValue();
                    //for (int i = 0; i < iDepth; i++) sRedirectURL = "../" + sRedirectURL;
                    Utility.processRedirect(getServletContext(), request, response, sRedirectURL, null);
                    return;
                }
                else
                {
                    //Set the error object and log this
                }
            }
        }
	}

    /**
     *
     * @param      sFileIdentifier
     * @param      cf
     * @return	   String
     */
	private String getCachedFilePath(String sFileIdentifier, CachedFile cf)
	{
        //Look up the file in the hashtable.
        if (cf == null )
        {
            cf = (CachedFile)htFiles.get(sFileIdentifier);
		}

        if ( cf != null )
        {
            //We need to check that the file has finished downloading.
            //If it has not then loop until it completes downloading
            while (!cf.finishedDownloading());

            //If we find it then look up the location on disk and verify that the file exists.
            File f = new File(sCacheFolderPath + sSeparator + cf.getName());
            if( f.exists() )
            {
                //Check whether it is a directory.
                if( f.isDirectory() )
                {
                    //If it is then send back the Path to the main.html file.
                    return cf.getName() + sSeparator + "main.html";
                }
                //If it is not a directory then just send back the path to the file
                return cf.getName();
            }
        }
        return null;
	}

    /**
     *
     * @param      sContextPath
     * @param      sFileIdentifier
     * @param      cf
     * @return	   String
     */
    private String getRedirectURL(String sFileIdentifier, CachedFile cf)
    {
        //Look up the file in the hashtable.
        if (cf == null )
        {
            cf = (CachedFile)htFiles.get(sFileIdentifier);
		}

        if ( cf != null )
        {
            //We need to check that the file has finished downloading.
            //If it has not then loop until it completes downloading
            while (!cf.finishedDownloading());

            //If we find it then look up the location on disk and verify that the file exists.
            File f = new File(sCacheFolderPath + sSeparator + cf.getName());
            if( f.exists() )
            {
                //Check whether it is a directory.
                if( f.isDirectory() )
                {
                    //If it is then send back the URL to the main.html file.
                    return "/" + sCacheFolder + "/" + cf.getName() + "/main.html";
                }
                //If it is not a directory then just send back the url to the file
                return "/" + sCacheFolder + "/" + cf.getName();
            }
        }
        return null;
    }

    /**
     *
     * @param      dph
     * @param      umap
     * @return	   String
     */
    static final String getFileIdentifier(DefaultParamHandler dph, UserMap umap)
    {
		boolean isTransientReport = (dph.getParameter("connectionhandle") != null);
		
		String sToReturn = dph.getParameter("fileid");
		if (sToReturn == null || (sToReturn.trim()).length() == 0)
		{
			//If the id doesn't exist
			//Retrieve the name element
			sToReturn = dph.getParameter("name");

            //If we don't find the name then try to get the outputFileName
            if (sToReturn == null || (sToReturn.trim()).length() == 0)
            {
			    sToReturn = dph.getParameter("outputFileName");
			}

			if ( sToReturn != null && (sToReturn.trim()).length() > 0)
			{
				//Retrieve the version
				String sVersion = dph.getParameter("version");

				if ( sVersion != null && (sVersion.trim()).length() > 0)
				{
					sToReturn += "__" + sVersion;
				}
			}
		}

        //Get the user details and retrieve the serverUrl and volume name.
        if ( umap != null )
        {
			if (isTransientReport)
			{
            	return sToReturn +  "__transient" + "__" + umap.getServerURL() + "__" + umap.getVolume();
			}
			else
			{
            	return sToReturn +  "__" + umap.getServerURL() + "__" + umap.getVolume();
			}
		}

        return null;
    }

	/**
	 *
	 * @param      dph
	 * @param      userMap
	 * @return	   HttpResponse
	 * @exception  ServletException
	 */
	protected final HttpResponse submitRequest(HttpServletRequest hrq, DefaultParamHandler dph, UserMap userMap) throws ServletException
	{
        return null;
	}
}

/**
 *
 * @author  Actuate Corporation
 * @version 1.0
 */
class CachedFile
{
	/**	*/
    private String sFileOrDirName = null;
	/**	*/
    private long lLastUpdated = System.currentTimeMillis();
	/**	*/
    private boolean bFinishedDownloading = false;

    /**
     *
     * @return	 String
     */
    final String getName()
    {
        return sFileOrDirName;
    }

    /**
     *
     * @return	 long
     */
    final long getLastUpdateTime()
    {
        return lLastUpdated;
    }

    /**
     *
     * @return	 boolean
     */
    final boolean finishedDownloading()
    {
        return bFinishedDownloading;
    }

    /**
     *
     * @param      sName
     */
    final void setName(String sName)
    {
        this.sFileOrDirName= sName;
    }

    /**
     *
     */
    void setFinishedDownloading()
    {
        bFinishedDownloading = true;
        lLastUpdated = System.currentTimeMillis();
    }

    /**
     *
     * @return	 String
     */
    public String toString() { return getName(); }
}

/**
 *
 * @author  Actuate Corporation
 * @version 1.0
 */
class FileDownloader extends DefaultSoapHandler
{
	/**	*/
    private transient Vector vAttachments = new Vector();
	/**	*/
    private transient int iCurrent = 0;
	/**	*/
    private transient int iSize = 0;
	/**	*/
    private transient FileFolder file = null;
	/**	*/
    private transient boolean bProcessingAttachments = false;
	/**	*/
    private transient String sFileName = null;
	/**	*/
    private transient String sExtension = "";
	/**	*/
    private transient String sTempFile = null;
	/**	*/
    private transient boolean bTempDirectory = false;
	/**	*/
    private transient CachedFile cf = null;

    /**
     *
     * @param      parentServlet
     * @param      request
     * @param      response
     * @param      userMap
     * @param      dph
     * @exception  ServletException
     * @exception  IOException
     */
    void downloadFile(AcServlet parentServlet, HttpServletRequest request, HttpServletResponse response, UserMap userMap, DefaultParamHandler dph) throws ServletException, IOException
    {
        if (request.getAttribute("objectId") != null)
        {
            request.setAttribute("fileid", request.getAttribute("objectId"));
		}

		String[][] saLegalParameters =
		{
			{ "fileid", "" },//objectID
			{ "name", "" }, //Objectname (filename)
			{ "version", "" }, // versionID
			{ "outputFileName", "" }, // outputName
			{ "outputType", "" } // outputType
		};

		String[] saRequiredParameters = {};
		String[][][] saConditionalParameters = { { {"fileid"}, {"name"} } };
        HttpResponse hr = null;
        
		try
		{
			parentServlet.updateInternalProperties(request, saLegalParameters, saRequiredParameters, saConditionalParameters, userMap, dph);
            if (request.getAttribute("source.servlet") != null)
            {
                String sFileID = ((Integer) request.getAttribute("objectId")).toString();
                String sOutputFileType = (String) request.getAttribute("outputFileType");
                String sOutputFileName = (String) request.getAttribute("outputFileName");
                String sPersistent = (String) request.getAttribute("persistent");

                dph.updateParameter("persistent", sPersistent);
                dph.updateParameter("fileid", sFileID);
                dph.updateParameter("outputType", sOutputFileType);
                dph.updateParameter("outputFileName", sOutputFileName);
                dph.updateParameter("name", sOutputFileName);
            }

            String repositoryType = userMap.getRepositoryType(); 
            if ( repositoryType != null && repositoryType.equalsIgnoreCase(iPortalRepository.REPOSITORY_STANDALONE) )
            {
            	request.setAttribute("userid", userMap.getUserName());
            	request.setAttribute("password", userMap.getPassword());
            	request.setAttribute(IPortalConsts.IPORTAL_SESSION_ID_KEY, userMap.getIPortalID());
            	request.setAttribute(IPortalConsts.VOLUME_PROFILE, userMap.getVolumeProfile());
            	request.setAttribute(IPortalConsts.REPOSITORY_TYPE, userMap.getRepositoryType());

            	AcRequestHandlerBean reqHandler = new AcRequestHandlerBean();
        		reqHandler.setRequest( request );
        		reqHandler.setResponse( response );

            	iPortalSession portalSession = IPortalAuth.authenticate( new HttpRequestParamHandler( reqHandler), true );
                if ( portalSession == null )
                {
                    PrintWriter pw = response.getWriter();
                    pw.write( "Authentication failed: Should have been redirected for authentication" );
                    pw.close();
                    return;
                }
            	downloadRepositoryFile(portalSession, request, response, dph, userMap);
            	return;
            }
            else
            	hr = submitRequest(parentServlet, dph, userMap);

			//Process the response
			SinglePart sp = null;

			int nPart = 0;
            IPortalFileTypeManager ftm = IPortalFileTypeManager.instance();
			FileType ft = null;
			int nRead = 0;
            while ((sp = hr.getNextPart()) != null) // PART LOOP
			{
				nPart++;
				if ( nRead < 0 )
				{
					StaticFuncs.info("FileDownloadServlet_downloadFile--Part no:" + nPart + " nRead: " + nRead);

					// iSize is the number of attachements and iCurrent is the number
					// of attachments currently processed.
					if ( iCurrent >= iSize )
					{
						hr.dumpResponse();
						sp.dumpSinglePart();

						// Show a 502 http error with a retry message.
						ResourceManager rm = StaticFuncs.getResources(getClass(), userMap.getLocale());
						String msg  = rm.getString(R_servlets.MSG_ERR_DOWNLOAD_RETRY_AGAIN);

						
						response.setContentType("text/html;charset=utf-8");
						response.sendError(response.SC_BAD_GATEWAY, msg);
						
						// Break from this loop since the end of the stream is reached.
						break;
					}
				}

				if (nPart == ServerResponseParser.SOAP_BLOCK)
				{
					parseSoapBlock(sp, response);
                    //Once we have parsed the soap block.
                    //if soap fault occurred, throw SoapFaultException.
                    if (eo != null)
                    {
                        throw new SoapFaultException(eo);
                    }

                    //Get the file type.
                    ft = ftm.getFileType(userMap.getLocale(), userMap.getServerURL(), userMap.getVolume(), file.getFileType(), userMap.getAuthID());

                    //Retrieve the file name
                    //DCS 52713: for DownloadTransientFile
                    sFileName = file.getContentId();


                    //IF the output type has been set then replace the file name with the type
                    if( dph.getParameter("outputType") != null )
                    {
                        if( dph.getParameter("outputFileName") != null )
                        {
                            sFileName = dph.getParameter("outputFileName");
						}
						if( dph.getParameter("outputname") != null )
						{
							sFileName = dph.getParameter("outputname");
						}

						if ( sFileName == null )
						{
							sFileName = (String) request.getSession().getAttribute("outputFileName");
						}

                        String sOutputType = dph.getParameter("outputType");
                        ft = ftm.getFileType(userMap.getLocale(), userMap.getServerURL(), userMap.getVolume(), sOutputType, userMap.getAuthID());

                        if( sFileName == null )
                        {
                            sFileName = "output." + sOutputType;
						}
                    }

                    //If the file type is null here and
                    //the filename has been set
                    //try to get the file type from the name
                    if (ft == null && sFileName != null)
                    {
                        ft = StaticFuncs.getFileType(sFileName , userMap.getServerURL(), userMap.getVolume(), userMap.getAuthID(), userMap.getLocale());
                    }

                    //Extract just the name from it.
                    int iSlash = sFileName.lastIndexOf("/");
                    if (iSlash > -1)
                    {
                        sFileName = sFileName.substring(iSlash + 1);
					}
                    //Extract the extension
                    final int iDot = sFileName.lastIndexOf(".");
                    if ( iDot > -1 )
                    {
                        sExtension = sFileName.substring(iDot);
                        sFileName = sFileName.substring(0, iDot);
                    }
                    if( ft != null && !ft.getName().equals("$$$"))
                    {
                        sExtension = "." + ft.getExtension();
					}

					sFileName = StaticFuncs.getFriendlyDownloadFileName(sFileName);

                    iSize = vAttachments.size();

                    //If the filetype uses the web server file system or the number of attachments is more than 1
                    //then make it use the file system
                    if (FileDownloadServlet.sCacheFolderPath != null && ((ft != null && ft.getWebServerFileSystem()) || iSize > 1))
                    {
                        //Generate the file identifier
                        String sFileIdentifier = FileDownloadServlet.getFileIdentifier(dph, userMap);
                        //Get an available name for the new file or directory.
                        sTempFile = null;
                        if(iSize > 1 )
                        {
                            bTempDirectory = true;
                            sTempFile = StaticFuncs.getUniqueFile(FileDownloadServlet.sCacheFolderPath + FileDownloadServlet.sSeparator + StaticFuncs.encode(sFileName, '_'));
                            File f = new File(sTempFile);
                            f.mkdir();
                        }
                        else
                        {
                            sTempFile = StaticFuncs.getUniqueFile(FileDownloadServlet.sCacheFolderPath + FileDownloadServlet.sSeparator + StaticFuncs.encode(sFileName, '_'), sExtension);
                            //Write some dummy content into the file to hold it until we start writing the actual content.
                            FileOutputStream fos = new FileOutputStream(sTempFile);
                            fos.write("-----------------------".getBytes());
                            fos.close();
                        }

                        cf = new CachedFile();
                        //Strip the file name from the path
                        String sName = sTempFile;
                        iSlash = sTempFile.lastIndexOf(FileDownloadServlet.sSeparator);
                        if (iSlash > -1)
                        {
                            sName = sTempFile.substring(iSlash + 1);
						}

                        cf.setName(sName);
                        //Add this to the hashtable
                        CachedFile tmpCf = (CachedFile) FileDownloadServlet.htFiles.put(sFileIdentifier, cf);
                        if (tmpCf != null)
                        {
				            File f = new File(FileDownloadServlet.sCacheFolderPath + FileDownloadServlet.sSeparator + tmpCf.getName());
				            synchronized(tmpCf)
				            {
					            FileDownloadServlet.deleteFile(f);
				            }
                        }
                    }
				}
				else if (nPart >= ServerResponseParser.ATTACHMENT_BLOCK)
				{
                    //If the file is not cached then set the content type
                    if ( cf == null )
                    {
                        final boolean bDownload = (dph.getParameter("showDownloadDialog") != null);
                        if( bDownload || ft == null || ft.getContentType() == null || (ft.getContentType().trim()).length() == 0 )
                        {
							if (StaticFuncs.isCompoundDocument(ft.getName()) && iSize == 1 && !bDownload)
							{
								//If it comes in here then it means that the compound document has just one file in it.
								//We can just stream it back.
								String sFileName =  (String)vAttachments.elementAt(0);

								sFileName = StaticFuncs.getFriendlyDownloadFileName(sFileName);
								
								//FileType ftTemp = ftm.getFileType(userMap.getLocale(), userMap.getServerURL(), userMap.getVolume(), sOutputType, userMap.getAuthID());
								FileType ftTemp = StaticFuncs.getFileType(sFileName, userMap.getServerURL(), userMap.getVolume(), userMap.getAuthID(), userMap.getLocale());
								//if there is no content type then set it to application/octet stream
								if (ftTemp != null && ftTemp.getContentType() != null && (ftTemp.getContentType().trim()).length() > 0 )
								{
									response.setContentType(ftTemp.getContentType());
									response.setHeader ("Content-Disposition","inline; filename=\"" + sFileName+"\"");
									
								}
							}
							else
							{
								response.setContentType("application/octet-stream");
								response.setHeader ("Content-Disposition","attachment; filename=\"" + sFileName + sExtension+"\"");
							}
                        }
                        else if(ft.getContentType().equalsIgnoreCase("text/psv") || ft.getContentType().equalsIgnoreCase("text/tsv"))
                        {
                        	// SCR#98038 - The content type set by the server for these file types, is not recognized by browser.
                        	// Setting it to application/octet-stream, since that's what we set for unknown filetypes.
                        	response.setContentType("application/octet-stream");
                        	response.setHeader ("Content-Disposition","attachment; filename=\"" + sFileName + sExtension+"\"");
                        }
                        else
                        {
							response.setContentType(ft.getContentType());
							response.setHeader ("Content-Disposition","inline; filename=\"" + sFileName + sExtension +"\"");
                        }
                        
                        StaticFuncs.setBrowserCacheResponseHeader( response, false );
                        nRead = parseAttachment(sp, response.getOutputStream());
                    }
                    else
                    {
                        OutputStream os = null;
                        if ( iCurrent < iSize )
                        {
                            String sContentID =  (String)vAttachments.elementAt(iCurrent);

                            os = (iSize == 1) ? new FileOutputStream(sTempFile) : new FileOutputStream(sTempFile + FileDownloadServlet.sSeparator + sContentID);
                            iCurrent++;
                        }
                        else
                        {
                            //This condition should never arise.
                            //However, in case it does this will just discard any additional attachments.
                            os = new ByteArrayOutputStream();
                        }
					    nRead = parseAttachment(sp, os);
                        os.flush();
                        os.close();
                    }
				}
			}
		}
		catch (SoapFaultException sfe)
		{
            try
            {
    			response.reset();
			}
			catch (IllegalStateException lse)
			{
				StaticFuncs.error(FileDownloadServlet.class.getName(), lse.toString(), lse);
				/* QUIETLY SUPPRESS */
			}
            //sfe.printStackTrace();

			ErrorObject eo = sfe.getErrorObject();
			if (dph != null)
			{
				String s = (dph.exists("id")? dph.getParameter("id"):dph.getParameter("name"));
				if (s != null)
				{
					eo.setProperty("item", s);
				}
			}

			eo.setProperty("class", getClass().getName());
			eo.setProperty("function", "processResponse");
            eo.setProperty("clienterrsource", "Servlet");
			eo.setProperty("clientrequest", "DownloadFile");
			eo.setProperty("operation", "Download a file"); //i18n
			parentServlet.loadErrorPage(null,null,request, response, false, eo);
		}
		catch (Exception ex)
		{
            ex.printStackTrace();

            HttpRequest hq = hr.getRequest();
            StaticFuncs.error(getClass().getName(), "An internal exception occurred.", ex);

            try
            {
    			response.reset();
			}
			catch (IllegalStateException lse)
			{
				StaticFuncs.error(FileDownloadServlet.class.getName(), lse.toString(), lse);
				/* QUIETLY SUPPRESS */
			}
			ErrorObject eo = new ErrorObject();
			if (dph != null)
			{
				String s = (dph.exists("id")? dph.getParameter("id"):dph.getParameter("name"));
				if (s != null)
				{
					eo.setProperty("item", s);
				}
			}
			eo.setProperty("class", getClass().getName());
            eo.setProperty("errorcode", StaticFuncs.getErrorCode("JSRVLT_", getClass(), "processResponse"));
			eo.setProperty("function", "processResponse");
            eo.setProperty("clienterrsource", "Servlet");
			eo.setProperty("clientrequest", "DownloadFile");
			eo.setProperty("operation", "Download a file"); //i18n
            eo.setClientException(ex);
			parentServlet.sendErrorRedirect(request, response, "/iportal/activePortal/errors/error.jsp", eo);
		}
		finally
		{
			String connectionHandle = (String) request.getSession().getAttribute("connectionHandle");
			if (connectionHandle != null  )
			{
				request.getSession().removeAttribute("connectionHandle");
			}
			
			if ( request.getSession().getAttribute("saveoutput") != null )
			{
				request.getSession().removeAttribute("saveoutput");
			}
			
			String fileId  = (String) request.getSession().getAttribute("fileid");
			if ( fileId != null)
			{
				request.getSession().removeAttribute("fileid");
			}
			
			String name = (String) request.getSession().getAttribute("name");
			if ( name != null )
			{
				request.getSession().removeAttribute("name");
			}
			
			String outputFilename = (String) request.getSession().getAttribute("outputFileName");
			if ( outputFilename != null )
			{
				request.getSession().removeAttribute("outputFileName");
			}
			
			String outputType  = (String) request.getSession().getAttribute("outputType");
			if (outputType != null )
			{
				request.getSession().removeAttribute("outputType");
			}
			
			
			
		
		}
        //Once we are done downloading
        //Update the cache file status
        if ( cf != null )
        {
            cf.setFinishedDownloading();
		}
    }

	/**
     *
	 * @return CachedFile
     */
    final CachedFile getCachedFile()
    {
        return cf;
    }

    /**
     * Download a file from the repository
     * @param portalSession
     * @param request
     * @param response
     * @param userMap
     * @param dph
     * @throws IOException
     */
    private final void downloadRepositoryFile(iPortalSession portalSession, HttpServletRequest request, HttpServletResponse response, DefaultParamHandler dph, UserMap userMap) throws IOException
    {
        String sFileName = dph.getParameter("name");
    	response.setContentType("text/html");
        if ( ( sFileName == null ) || ( sFileName.trim().length() <= 0 ) )
        {
            PrintWriter pw = response.getWriter();
            pw.write( "Servlet parameter \"filename\" is missing.");
            pw.close();
            return;
        }

		//Retrieve the version
		String sVersion = dph.getParameter("version");

		if ( sVersion != null && (sVersion.trim()).length() > 0)
		{
			sFileName += ";" + sVersion;
		}
         
	     String fileName = sFileName;
	     int slashPos = sFileName.lastIndexOf( '/' );
	     if ( slashPos != -1 )
	     {
	         fileName = sFileName.substring( slashPos + 1 );
	     }
	
	    // Get outputFileName for setting in header
	    String sOutputName = dph.getParameter("outputFileName");
	    if( sOutputName == null ) sOutputName = sFileName; // If caller doesn't want a different name for output, original fileName should be good enough.
	    int slashPosition = sOutputName.lastIndexOf( '/' );
	    if ( slashPosition != -1 )
	    {
	    	sOutputName = sOutputName.substring( slashPosition + 1 );
	    }
	    
		IPortalFileTypeManager ftm = IPortalFileTypeManager.instance();
		FileType ftTemp = null;
		FileTypes fileTypeList = null;

         try
         {
			fileTypeList =
				ftm.getRepositoryFileTypes(iPortalRepository.REPOSITORY_STANDALONE, userMap.getLocale(), userMap.getServerURL(), userMap.getVolume(), userMap.getAuthID(), false);
			
			 
			String ext = StaticFuncs.getFileExtension(fileName);
			ftTemp = fileTypeList.getFileType(ext);
			if (ftTemp != null && ftTemp.getContentType() != null && (ftTemp.getContentType().trim()).length() > 0 )
			{
				response.setContentType(ftTemp.getContentType());
				response.setHeader ("Content-Disposition","inline; filename=\"" + sOutputName + "\"");
			} else {
				response.setContentType( "application/octet-stream" );
				response.setHeader ("Content-Disposition","attachment; filename=\"" + sOutputName + "\"");
			}

			IInputRepositoryFile inputFile = portalSession.getFile( sFileName );
			InputStream is = inputFile.getInputStream();
			
			OutputStream os = response.getOutputStream();
			parseAttachment(is, os);
			is.close();
			os.close();
         }
         catch ( RepositoryFileInvalidItemException e )
         {
             PrintWriter pw = response.getWriter();
             e.printStackTrace( pw );
         }
         catch ( RepositoryFileException e )
         {
             PrintWriter pw = response.getWriter();
             e.printStackTrace( pw );
         }
         catch ( IOException e )
         {
             PrintWriter pw = response.getWriter();
             e.printStackTrace( pw );
         }
    }
    
	/**
     *
	 * @param      parentServlet
	 * @param      dph
	 * @param      userMap
	 * @return	   HttpResponse
	 * @exception  Exception
     */
    private final HttpResponse submitRequest(AcServlet parentServlet, DefaultParamHandler dph, UserMap userMap) throws Exception
	{
    	
		Document d = AcServlet.createDocument();
        final boolean bHasCH = dph.exists("connectionHandle");
		Element eDownload = parentServlet.createRootElement(d,
            (bHasCH && !dph.exists("persistent"))
                ? "DownloadTransientFile"
                : "DownloadFile"); // XML API

		//get the ID
		String sValue = dph.exists("persistent") ? null : dph.getParameter("fileid");
		if ( sValue != null && (sValue.trim()).length() > 0)
		{
			//If found create the id element
			parentServlet.createChildElement(d, eDownload, "FileId", sValue);
		}
		else
		{
			//If the id doesn't exist
			//Retrieve the name element
			sValue = dph.getParameter("name");
			if (sValue != null && (sValue.trim()).length() > 0)
			{
				String sName = sValue;
				//Retrieve the version
				sValue = dph.getParameter("version");

				if ( sValue != null && (sValue.trim()).length() > 0)
				{
					sName += ";" + sValue;
				}
				parentServlet.createChildElement(d, eDownload, "FileName", sName);
			}
		}

        if (dph.exists("returnContents"))
        {
            sValue = (Boolean.valueOf(dph.getParameter("returncontents"))).toString();
            parentServlet.createChildElement(d, eDownload, "DecomposeCompoundDocument", sValue);
        }

		SoapHeader sh = new SoapHeader();
		if (bHasCH)
		{
			sh.addProperty("ConnectionHandle", dph.getParameter("connectionHandle"));
			

		}
		
		sh.addProperty("AuthId", userMap.getAuthID());
		sh.addProperty("TargetVolume", userMap.getVolume());
		sh.addProperty("Locale", (userMap.getLocale()).getID());

		SoapBody sb = new SoapBody();
		sb.setContent(d);

		SoapEnvelope se = new SoapEnvelope();
		se.setHeader(sh);
		se.setBody(sb);

        HttpRequest hrq = parentServlet.getConnection(userMap);
        return se.sendTo(hrq);
	}


    /**
     *
     * @return	ErrorObject
     */
    final ErrorObject getError()
    {
        return eo;
    }

	/**
	 *
	 * @param      sNameSpaceURI
	 * @param      sLocalName
	 * @param      sQualifiedName
	 * @param      attributes
	 * @exception  SAXException
	 */
	public void startBodyElement(String sNameSpaceURI, String sLocalName, String sQualifiedName, Attributes attributes) throws SAXException
    {
        super.startBodyElement(sNameSpaceURI, sLocalName, sQualifiedName, attributes);
        if ( sLocalName.equals("CONTAINEDFILES") )
        {
            bProcessingAttachments = true;
        }
    }

    /**
     *
     * @param      ch
     * @param      start
     * @param      length
     * @exception  SAXException
     */
    public void bodyCharacters(char[] ch, int start, int length) throws SAXException
    {
        if( !bProcessingAttachments )
        {
            if ( file == null )
            {
                file = new FileFolder();
			}
            file.setProperty(sLocalName, new String(ch, start, length));
        }
        else
        {
            if ( sLocalName.equals("CONTENTID") )
            {
                vAttachments.addElement(new String(ch, start, length));
			}
        }
    }

	/**
	 *
	 * @param      is
	 * @param      hsr
	 * @exception  SAXException
	 * @exception  HttpException
	 * @exception  IOException
	 */
	private void parseSoapBlock(InputStream is, HttpServletResponse hsr) throws SAXException, HttpException, IOException
	{
		SoapParser sp = new SoapParser(this);
		sp.parse(is);
	}

	/**
	 *
	 * @param      is
	 * @param      os
	 * @exception  IOException
	 */
	private int parseAttachment(InputStream is, OutputStream os) throws IOException
	{
		final int inSize = 4096; // DOESNT MATTER IF HARDCODED
		byte[] ba = new byte[inSize];
		while  ( true )
		{
			final int nRead = is.read(ba, 0, inSize);
			if (nRead > 0)
			{
				os.write(ba, 0, nRead);
			}
			else if (nRead < 0)
			{
				return nRead;
			}
		}
	}
}
