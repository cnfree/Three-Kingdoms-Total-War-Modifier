/*
 * Created on Sep 13, 2006
 */
package com.actuate.iportal.license;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.actuate.activeportal.beans.FeatureOptionsBean;
import com.actuate.common.license.BaseLicenseManager;
import com.actuate.common.license.AJCReleaseOptions;
import com.actuate.common.license.LicenseFile;
import com.actuate.common.license.LicenseInfo;
import com.actuate.common.license.LicensedOption;
import com.actuate.common.util.AcLocale;
import com.actuate.common.util.FileType;
import com.actuate.reportcast.utils.beans.message.MessageBean;
import com.actuate.reportcast.utils.beans.message.MessageItem;
import com.actuate.common.license.ActuLicenseException;

public class LicenseManager extends BaseLicenseManager {
		
	private static boolean		isBirtReportAllowed;
	private static boolean		isBirtInteractiveViewerAllowed;
	private static boolean		isSpreadAllowed;
	private static boolean		isBIRTReportStudioAllowed;
	private static String		expirationDateAsString;
	private static String		daysTillExpirationAsString;
	private static boolean		isDeploymentKitAllowed;
	
	private static boolean		isBIRT360Allowed;
	private static boolean		isBIRTDataAnalyzerAllowed;
	private static Integer licenseId;
	
	public static final Logger logger = Logger.getLogger(LicenseManager.class.getName());
		
	protected LicenseManager() {}
	
	public synchronized static void initialize()
	{
		BaseLicenseManager.Initialize();
		disableAllLicenseOptions();
	}
	
	/*
	 * @return true if license is valid.  false if license is not valid.
	 */
	public static boolean initialize( InputStream licenseFile, String licenseFilePath, boolean isBRD )
	{
		String isBRDSet = System.getProperty("ACTUATE_DESIGNER_PRO");
		int fileType ;
		String licenseLogStr = null;
		if(isBRDSet != null && isBRDSet.equalsIgnoreCase("true"))
		{
			fileType = LicenseFile.Type.BRD;
			licenseLogStr =  "************** BIRT Report Designer License Information ***************" + NEWLINE;
		}
		else
		{
			fileType = LicenseFile.Type.AJC;
			licenseLogStr =  "************** Actuate Java Component License Information ***************" + NEWLINE;
		}
		
		final LicenseInfo licenseInfo = BaseLicenseManager.Initialize( fileType, licenseFile, licenseFilePath );
        if ( !checkIsValid() )
            return false;
        setLicenseId( licenseInfo.GetLicenseID() );

        licenseLogStr += GetLicenseTermsToLog();
        logger.log( Level.SEVERE, licenseLogStr );

        if ( isBRD )
        {
            enableOptionsForBRD();
        }
        else
        {
            CheckOptions( licenseInfo );
        }

        readExpirationInfo( licenseInfo );
        return true;
	}
	
	
	private static void readExpirationInfo(LicenseInfo licenseInfo)
	{
	    expirationDateAsString          = licenseInfo.GetExpirationDateAsString();
        daysTillExpirationAsString      = licenseInfo.GetDaysTillExpirationAsString();
	}
	
	/**
	 * 
	 */
	private static void enableOptionsForBRD()
	{
		isBirtInteractiveViewerAllowed  = true ;
		isBirtReportAllowed				= true ;
	}
	
	/**
	 * For information console disable all options to now allow local
	 */
	private static void disableAllLicenseOptions()
	{
		isBirtInteractiveViewerAllowed  = false ;
		isBirtReportAllowed				= false ;
		isBIRTReportStudioAllowed   	= false ;
		isSpreadAllowed					= false ;
		isDeploymentKitAllowed  		= false ;

		isBIRT360Allowed				= false;	
		isBIRTDataAnalyzerAllowed		= false;
	}
	
	
	private static void CheckOptions(final LicenseInfo licenseinfo) 
	{
		isBirtInteractiveViewerAllowed  = licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_BIRTINTERACTIVEVIEWER);
		isBirtReportAllowed				= licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_BIRTREPORT);
		isBIRTReportStudioAllowed   	= licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_BIRTREPORTSTUDIO);
		isSpreadAllowed					= licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_SPREAD);
		isDeploymentKitAllowed  		= licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_DEVELOPMENTKIT);
		isBIRTDataAnalyzerAllowed          = licenseinfo.IsOptionEnabled(AJCReleaseOptions.I_OPTION_BIRTDATAANALYZER);
	}
	
	public static String getExpirationDateAsString() { return expirationDateAsString; }
	public static String getDaysTillExpirationAsString() { return daysTillExpirationAsString; }
	
	
	private static void checkLicensed(boolean isEnterprise) throws ActuLicenseException
	{
	    if (!isEnterprise)
        {
	        //As of 5/10/2012 checkIsValid() checks only workgroup mode license so do not use it for enterprise mode.
            if ( !checkIsValid() )
            {
                throw new ActuLicenseException(
                        ActuLicenseException.LICENSE_ERROR_EXPIRED, null );
            }
        }
	}
	
	/**
	 * This method is used to enforce BRS license option
	 * @param featureInfobin
	 * @param isEnterprise
	 * @throws ActuLicenseException
	 */
	public static void checkBRSLicensed(FeatureOptionsBean featureInfobin, boolean isEnterprise) throws ActuLicenseException
	{
		checkLicensed(isEnterprise);
		if(!isBRSAllowed(featureInfobin, isEnterprise))
		{
			throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "BIRT Studio", null );
		}
	}
	
	/**
	 * This method is used to enforce IV license  option
	 * @param featureInfobin
	 * @param isEnterprise
	 * @throws ActuLicenseException
	 */
	public static void checkIVLicensed(FeatureOptionsBean featureInfobin, boolean isEnterprise) throws ActuLicenseException
	{
		checkLicensed(isEnterprise);
		if(!isIVAllowed(featureInfobin, isEnterprise))
		{
			throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "Interactive Viewing", null );
		}
	}
	
	/**
	 * This method is used to enforce SV license option
	 * @param featureInfobin
	 * @param isEnterprise
	 * @throws ActuLicenseException
	 */
	public static void checkSVLicensed(FeatureOptionsBean featureInfobin, boolean isEnterprise) throws ActuLicenseException
	{
		checkLicensed(isEnterprise);
		if(!isSVAllowed(featureInfobin, isEnterprise))
		{
			throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "BIRT Report", null );
		}
	}
	
	/**
	 * This method is called for AJC/BRD/IC i.e. not for enterprise license check. It enforces BIRT Report and Spread license option 
	 * @param fileType
	 * @throws ActuLicenseException
	 */
	public static void checkExeorViewLicensed(String fileType, Locale locale) throws ActuLicenseException
	{
	    //As of 5/10/2012 this method is only used for workgroup mode so set isEnterprise to false
	    boolean isEnterprise = false;
		checkLicensed(isEnterprise);
		
		//check for birt report option
		if( isBIRTReport(fileType) )
		{
			if(!isBirtReportAllowed)
			{
				throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "BIRT Report", locale );
			}
		}
		// check for spread option
		else if( isESSReport(fileType))
		{
			if(!isSpreadAllowed)
			{
				throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "e.SpreadSheet", locale );
			}
		}
		// for all other file types throw exception
		else
		{
			throw new ActuLicenseException (  ActuLicenseException.LICENSE_ERROR_COMMON, fileType, locale  );
		}
	}
	
	
	public static boolean isBRSAllowed( FeatureOptionsBean featureInfobin, boolean isEnterprise ) 
	{
		if(isEnterprise)
		{
			// we first check to see if iserver is sending BRS option. If not we check if license file on iportal has that option.
			return featureInfobin.birtReportStudioOptionEnabled();
		}
		else
		{
			return isBIRTReportStudioAllowed;
		}
	}
	
	public static boolean isIVAllowed( FeatureOptionsBean featureInfobin, boolean isEnterprise ) 
	{
		if(isEnterprise)
		{
			return featureInfobin.birtInterativeViewerOptionEnabled();
		}
		else
		{	
			return isBirtInteractiveViewerAllowed;
		}
	}
	
	/**
	 * This method is used by AJC client to avoid folder view if BIRTReport is not licensed
	 * @param featureInfobin
	 * @param isEnterprise
	 * @return
	 */
	public static boolean isSVAllowed( FeatureOptionsBean featureInfobin, boolean isEnterprise ) 
	{
		if(isEnterprise)
		{	
			return featureInfobin.birtReportOptionEnabled();
		}
		else
		{
			return isBirtReportAllowed;
		}
	}
	
	/**
	 * This method is used to verify DeploymentKit Option
	 * @return
	 */
	public static boolean isDeploymentKitAllowed() 
	{
		return isDeploymentKitAllowed;
	}
	
	private static boolean isBIRTReport(String fileType)
	{
		FileType ft  = FileType.getFileType(fileType);
		
		if(ft == FileType.RPTDESIGN || 
		   ft == FileType.RPTTEMPLATE ||
		   ft == FileType.RPTDOCUMENT ||
		   ft == FileType.BIZDESIGN ||
		   ft == FileType.BIZDOCUMENT  ||
		   ft == FileType.DASHBOARD ||
		   ft == FileType.GADGET ||
		   ft == FileType.DATADESIGN ||
		   ft == FileType.DATA ||
		   ft == FileType.DASHBOARDDOCUMENT ||
		   ft == FileType.CUBEVIEW
		  )
		{
			return true;
		}
		else
			return false;
	}
	
	private static boolean isESSReport(String fileType)
	{
		FileType ft  = FileType.getFileType(fileType);
		
		if(ft == FileType.VTF || ft == FileType.VTX || ft == FileType.SOX || ft == FileType.SOI)
		{
			return true;
		}
		else
			return false;
	}

	/**
	 * This method is used to enforce SV license option
	 * @param featureInfobin
	 * @param isEnterprise
	 * @throws ActuLicenseException
	 */
	public static void checkBIRT360Licensed(FeatureOptionsBean featureInfobin, boolean isEnterprise) throws ActuLicenseException
	{
		checkLicensed(isEnterprise);
		if(!isBIRT360Allowed(featureInfobin, isEnterprise))
		{
			throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "BIRT 360", null );
		}
	}
	
	/**
	 * "Data Selection" and "Data Visualization" menu items should not be available to the user.
	 * All other dashboard operation is allowed
	 * Dashboard in workgroup mode is not allowed.  If it is workgroup mode, false will be returned
	 * @param featureInfobin
	 * @param isEnterprise
	 * @return boolean
	 */
	public static boolean isBIRT360Allowed( FeatureOptionsBean featureInfobin, boolean isEnterprise ) 
	{
		if(isEnterprise)
		{
			return featureInfobin.birt360OptionEnabled();
		}
		else
		{
			return true;
		}
	}

	
	public static void checkBIRTDataAnalyzerLicensed(FeatureOptionsBean featureInfobin, boolean isEnterprise) throws ActuLicenseException
    {
        checkLicensed(isEnterprise);
        if(!isBIRTDataAnalyzerAllowed(featureInfobin, isEnterprise))
        {
            throw new ActuLicenseException( ActuLicenseException.LICENSE_ERROR_INVALID_OPTION, "BIRT Data Analyzer", null );
        }
    }
	
	/**
	 * handles .data, .datadesign and CubeView license checking 
	 * @param featureInfobin
	 * @param isEnterprise
	 * @return boolean
	 */
	public static boolean isBIRTDataAnalyzerAllowed( FeatureOptionsBean featureInfobin, boolean isEnterprise ) 
	{
		if(isEnterprise)
		{
			return featureInfobin.birtDataAnalyzerOptionEnabled();
		}
		else
		{
			// cubeview and .data file in workgroup mode 	
			return isBIRTDataAnalyzerAllowed;
		}
	}

	
    /**
     * Retrieve the display name or long descriptive name from ActivePortalResources.properties file
     * @param aclo
     * @param internalName
     * @return
     */
    public static String getLicenseDisplayName(AcLocale aclo, String internalName)
    {
    	String basekey = "LBL_LICENSE_DESC_";
		MessageItem licenseDesc = new MessageItem();
		licenseDesc.setLocale(aclo.getJavaLocale());
		licenseDesc.setKey(basekey+internalName);
		
		String localizedDesc = MessageBean.getMessage("com.actuate.activeportal.resources.ActivePortalResources", licenseDesc);
		if ( localizedDesc != null && localizedDesc.length() > 0 )
			return localizedDesc;
		
    	return internalName;
    }
    
    public static ArrayList getLocalizedSupportedOptions( AcLocale acLocale )
    {
    	ArrayList options = new ArrayList();
    	
		for (int idx = 0; idx < supportedOptions.size(); idx++)
		{
	    	LicensedOption option = (LicensedOption) supportedOptions.get(idx);
	    	String optionText = option.GetOptionName();
	    	optionText = LicenseManager.getLicenseDisplayName(acLocale, optionText);
			Integer numOfUser = option.GetUsers();
			String strNumOfUser = numOfUser.toString();
			StringBuffer buf = new StringBuffer(optionText + ": ");
			if (numOfUser.intValue() == 2147483647)
			{
				buf.append(LicenseManager.getLicenseDisplayName(acLocale, "LBL_UNLIMITED_USERS"));
			} 
			else
			{
				buf.append(strNumOfUser);
				buf.append(" " + LicenseManager.getLicenseDisplayName(acLocale, "LBL_LICENSD_USERS") );
			}
			options.add(buf.toString());
		}
    	
    	return options;
    }
    
    public static boolean getApplyWatermark()
    {
        return BaseLicenseManager.GetApplyWatermark();
    }
    
    public static String getWatermarkText()
    {
        return BaseLicenseManager.GetWatermarkText();
    }
    
    public static String getWatermarkType()
    {
        return BaseLicenseManager.GetWatermarkType();
    }
    
    public static boolean getIsNodeLocked()
    {
        return BaseLicenseManager.GetIsNodeLocked().booleanValue();
    }
    
    public static String getNodeLockType()
    {
        return BaseLicenseManager.GetNodeLockType();
    }

	public static void setLicenseId(Integer licenseId) 
	{
		LicenseManager.licenseId = licenseId;
	}

	public static Integer getLicenseId() 
	{
		return licenseId;
	}
    
}
